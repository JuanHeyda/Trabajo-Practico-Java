package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import Proyecto.UsuarioDAO;

public class Usuario extends BaseModelo{
	String usuario;
	String contrasenia;
	
	
	//CONSTRUCTORES
	public Usuario(String usuario, String contrasenia) {
		super();
		this.usuario = usuario;
		this.contrasenia = contrasenia;
	}
	public Usuario() {
		
	}
	
	//GETTERS AND SETTERS
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
	
	//FUNCIONES 
	//VALIDAR USUARIO
	public boolean Validacion() throws SQLException {
	
		UsuarioDAO usuario = new UsuarioDAO();
	
		if(usuario.ValidarUsuario(this.usuario, this.contrasenia) ){
			return true;
		}else {
			JOptionPane.showMessageDialog(null , "Error en Usuario y/o Contrase�a", "ERROR", JOptionPane.INFORMATION_MESSAGE );
			return false;
		}
	}
		
	//FUNCION PARA GENERAR USUARIO, SE EJECUTA UNA SOLA VEZ Y AL INICIO DEL PROGRAMA
	public void GenerarUsuario() {
			
		UsuarioDAO usuario = new UsuarioDAO();
		try {
			usuario.createTable();
			List<Usuario> users = usuario.getAll();
			
			if(users.isEmpty()) {
				
				Usuario obUsuario1 = new Usuario(); 
				obUsuario1.setUsuario("admin");
				obUsuario1.setContrasenia("admin");
				usuario.insert(obUsuario1);

			}else {
				//PARA CREAR OTRO USUARIO
				
//				Usuario obUsuario1 = new Usuario(); 
//				obUsuario1.setUsuario("admin");
//				obUsuario1.setContrasenia("admin");
//				usuario.insert(obUsuario1);
					
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	} 
	
	
}
