package ar.com.gugler.sgc.modelo;

public class Universidad {

	static void mostrarDatos(Persona per) {
		
		System.out.println("Nombre: " + per.getNombres());
		System.out.println("Apellido: " + per.getApellido()); 
		System.out.println("DNI: " + per.numeroDocumento); 
		System.out.println("Fecha de Nacimiento: " + per.getFechaNacimiento());
		System.out.println("Domicilio: " + per.domicilio); 
		System.out.println("Telefono: " + per.telefono); 
		System.out.println("E-mail: " + per.correoElectronico); 
		
	}
	
}
