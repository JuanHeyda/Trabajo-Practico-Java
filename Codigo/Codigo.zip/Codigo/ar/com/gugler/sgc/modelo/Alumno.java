package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import Proyecto.AlumnoDAO;

public class Alumno extends Persona {
	
	//PARAMETROS
	private String Legajo;
	
	
	
	//METODOS
	public String mostrarInformacion() {
		return "Nombre: " + super.getNombres() + "Apellido: " + super.getApellido() + "DNI: " + super.getNumeroDocumento();		
	}

	//GETTERS AND SETTERS
	public String getLegajo() {
		return Legajo;
	}

	public void setLegajo(String legajo) {
		Legajo = legajo;
	}

	//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumno other = (Alumno) obj;
		if (Legajo == null) {
			if (other.Legajo != null)
				return false;
		} else if (!Legajo.equals(other.Legajo))
			return false;
		return true;
	}

	//TO STRING
	@Override
	public String toString() {
		return "Alumno [Legajo=" + Legajo + ", numeroDocumento=" + numeroDocumento + ", apellido=" + apellido
				+ ", nombres=" + nombres + ", fechaNacimiento=" + fechaNacimiento + ", domicilio=" + domicilio
				+ ", telefono=" + telefono + ", correoElectronico=" + correoElectronico + "id= "+ this.getId() +"]";
	}
	
	
	//CONTRUCTOR
	public Alumno(Long numeroDocumento, String apellido, String nombres,
			LocalDate fechaNacimiento, String domicilio,
			String telefono, String correoElectronico, String legajo) {
		super(numeroDocumento, apellido, nombres, fechaNacimiento, domicilio,
				telefono, correoElectronico);
		Legajo = legajo;
	}
	
	

	public Alumno() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Alumno(Long numeroDocumento, String apellido, String nombres) {
		super(numeroDocumento, apellido, nombres);
	}

	public boolean Validacion() throws SQLException {
		
		AlumnoDAO alum = new AlumnoDAO();
	
		if(!alum.ValidarUsuario(this.numeroDocumento, this.apellido, this.nombres, this.fechaNacimiento, this.domicilio, this.telefono
			, this.correoElectronico, this.Legajo )) {
			return true;
	
		}else {
			JOptionPane.showMessageDialog(null , "Ya existe el alumno", "ERROR", JOptionPane.INFORMATION_MESSAGE );
			return false;
		}
	}
	
	//FUNCION PARA CREAR LA TABLA DE LA BD
	public void creartabla() throws SQLException {
		AlumnoDAO.createTable();
	}

	//DATOS DE UN ALUMNO SEGUN SU DNI
	public Alumno DatosAlumnoGuardar(long codAlum) throws SQLException {
		AlumnoDAO alumDao = new AlumnoDAO();
		return alumDao.DatosAlumGuardar(codAlum);
	}
	
	//INSERTO UN ALUMNO EN LA BD
	public void GenerarAlumno(Alumno aux) {
		AlumnoDAO alum = new AlumnoDAO();
		try {
			Alumno obAlumno = new Alumno(); 

			    obAlumno.setLegajo(aux.getLegajo());
				obAlumno.setApellido(aux.getApellido());
				obAlumno.setCorreoElectronico(aux.getCorreoElectronico());
				obAlumno.setNombres(aux.getNombres());
				obAlumno.setDomicilio(aux.getDomicilio());
				obAlumno.setNumeroDocumento(aux.getNumeroDocumento());
				obAlumno.setTelefono(aux.getTelefono());
				obAlumno.setFechaNacimiento(aux.getFechaNacimiento());
				alum.insert(obAlumno);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	} 
	
	//EXTRAIGO DATOS DE LA BD
	public List<Alumno> GetNombreBD() throws SQLException {
		AlumnoDAO dao = new AlumnoDAO();
		
		return dao.NombreAlum();
		
	}
	
	
	public long idExtraer(long numDoc) throws SQLException {
		AlumnoDAO alumDao = new AlumnoDAO();
		return alumDao.ExtraerId(numDoc);
	}
	
	//DE UNA LISTA DE DNI, EXTRAIGO TODOS LOS DATOS DE LOS ALUMNOS.
	public List<Alumno> DatosAlumnosGuardar(List<Long> aux) throws SQLException{
		AlumnoDAO dao = new AlumnoDAO();
		
		return dao.AlumnosGuardar(aux);
	}
	
	//MODIFICAR SEGUN UN ALUMNO
	public void Modificar(Alumno alum) throws SQLException {
		AlumnoDAO alumDao = new AlumnoDAO();
		
		alumDao.update(alum);
	}
	
	public void EliminarAlumno(Long dni) throws SQLException {
		AlumnoDAO alumDao = new AlumnoDAO();
		alumDao.EliminarAlumno(dni);
	}
	
}
