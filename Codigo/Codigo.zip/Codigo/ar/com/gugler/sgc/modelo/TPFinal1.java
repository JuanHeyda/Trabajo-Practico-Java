package ar.com.gugler.sgc.modelo;


import java.sql.SQLException;
/*
import java.time.LocalDate;
import java.util.List;

import ar.com.gugler.sgc.dao.AlumnoDAO;
import ar.com.gugler.sgc.dao.ProfesorDAO;
*/

public class TPFinal1 {
	public static void main(String[] args) throws SQLException  {
	/*	
		LocalDate fechaNacimiento = null;
		LocalDate fechaIngreso = null;
		
		fechaNacimiento = LocalDate.of(1999, 01, 23);
		
		Alumno estudiante = new Alumno();
		estudiante.setNombres("Juan");
		estudiante.setApellido("Heyda");
		estudiante.setDomicilio("por ahi 123");
		estudiante.setFechaNacimiento(fechaNacimiento);
		estudiante.setCorreoElectronico("juanpablo.23@...");
		estudiante.setNumeroDocumento("65487987");
		estudiante.setTelefono("11232496");
		estudiante.setLegajo("1");
				
		Alumno estudiante1 = new Alumno();
		estudiante1.setNombres("Jusdfsdfan");
		estudiante1.setApellido("Heydsdfa");
		estudiante1.setDomicilio("por asdfhi 123");
		estudiante1.setFechaNacimiento(fechaNacimiento);
		estudiante1.setCorreoElectronico("jsdfuanpablo.23@...");
		estudiante1.setNumeroDocumento("65487sdf987");
		estudiante1.setTelefono("112324sdf96");
		estudiante1.setLegajo("12222");
		
		Alumno estudiante2 = new Alumno();
		estudiante2.setNombres("Jn");
		estudiante2.setApellido("a");
		estudiante2.setDomicilio("por asdfhi 123");
		estudiante2.setFechaNacimiento(fechaNacimiento);
		estudiante2.setCorreoElectronico("jsdfuanpablo.23@...");
		estudiante2.setNumeroDocumento("3333333f987");
		estudiante2.setTelefono("112324sdf96");
		estudiante2.setLegajo("12222");

		
		fechaNacimiento = LocalDate.of(1988, 05, 19);
		fechaIngreso = LocalDate.of(2000,07,21);
		
		Profesores profesor = new Profesores();
		profesor.setNombres("Emanuel");
		profesor.setApellido("Goette");
		profesor.setCorreoElectronico("elEmaKapo-java@gmail.com");
		profesor.setNumeroDocumento("39123123");
		profesor.setCuil("4444444");
		profesor.setDomicilio("por ahi 321");
		profesor.setFechaIngreso(fechaIngreso);
		profesor.setFechaNacimiento(fechaNacimiento);
		profesor.setTelefono("123444");
		
		Curso curso = new Curso();
		
		curso.setNombre("Programacion en Java");
		
		curso.setProfesor(profesor);
		
		curso.agregarAlumno(estudiante);
		curso.agregarAlumno(estudiante1);
		curso.agregarAlumno(estudiante2);
		
		
		Universidad.mostrarDatos(curso.Profesor);
		
		System.out.println();
		
		for (Alumno a: curso.listaAlumnos) {
			
			Universidad.mostrarDatos(a);
			System.out.println();
		}
		
		
		//TABLA PROFESOR
		ProfesorDAO.createTable();
		ProfesorDAO daoProfe = new ProfesorDAO();
		
		//daoProfe.insert(profesor);
		
		List<Profesores> profe = daoProfe.getAll();
		
		
		System.out.println("EL PROFESOR ES");
		
		for (Profesores a: profe) {
			
			Universidad.mostrarDatos(a);
			System.out.println();
		}
		
		

		
		//TABLA ESTUDIANTES
		
		
		/*for(int i = 0 ; i < curso.listaAlumnos.size(); i++) {
			for(int j = 0; j < estudiantes.size(); j++) {
				
				if(estudiantes.get(i) != curso.listaAlumnos.get(i)) {
				
				}
				
			}
			
		}*/
		
		
	}

}
