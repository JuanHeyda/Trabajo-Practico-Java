package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

import Proyecto.CursoDAO;


public class Curso extends Asignatura implements Administrable{
	private int cupo;
	
	/*public void agregarAlumno(Alumno alu) {
		
		if(admiteInscripciones() == true) {
			listaAlumnos.add(alu);
		}else {
			System.out.println("No se pueden agregar mas alumnos. ");
		}
		
	}*/
	
	public void eliminarAlumno(Alumno alu) {
		
		listaAlumnos.remove(alu);
		
	}	
	
	
	public boolean admiteInscripciones() {
		
		if(this.listaAlumnos.size() < this.cupo) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
	//GETTERS AND SETTERS
	public int getCupo() {
		return cupo;
	}
	public void setCupo(int cupo) {
		this.cupo = cupo;
	}
	
	//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Curso other = (Curso) obj;
		if (cupo != other.cupo)
			return false;
		return true;
	}
	
	//TO STRING
	@Override
	public String toString() {
		return "Curso [cupo=" + cupo + "]";
	}
	
	//CONSTRUCTORES
	public Curso(int codigo, String nombre, List<Alumno> listaAlumnos, Profesores profesor, int cupo) {
		super(codigo, nombre, listaAlumnos, profesor);
		this.cupo = cupo;
	}

	public Curso() {
		// TODO Auto-generated constructor stub
	}

	public Curso(int cupo2) {
		// TODO Auto-generated constructor stub
		this.cupo = cupo2;
	}
	
	//DEVUELVE AL CURSOWINDOWS UN LIST DE TODOS LOS CUPOS QUE EXISTEN ALMACENADOS
	public DefaultListModel<Integer> CursosGuardados(){
		
		DefaultListModel<Integer> cupos = new DefaultListModel<Integer>();
		CursoDAO dao = new CursoDAO();
		
		try {
			List<Curso>curso = dao.getAll();
			
			for(Curso i : curso) {
				cupos.addElement(i.getCupo());
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		burbuja(cupos);
		
		
		return cupos;
		
	} 
	
	//FUNCION PARA ORDENAR LOS CUPOS A LA HORA DE MOSTRARLO EN EL SCROLL
	public static void burbuja(DefaultListModel<Integer> cupos ){
        int i, j, aux;
        
        for(i=0;i<cupos.size()-1;i++) {
             for(j=0;j<cupos.size()-i-1;j++) {
                  if(cupos.get(j+1)<cupos.get(j)){
                     aux=cupos.get(j+1);
                     cupos.set(j+1, cupos.get(j));
                     cupos.set(j,aux);
                  }
             }
        }
	}
	
	//ALMACENA UN CURSO EN LA BASE DE DATOS
	public void GuardarCurso(Curso curso) {
	
		CursoDAO dao = new CursoDAO();
		
		try {
			dao.insert(curso);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null , "Guardado!", "Felicidades (?", JOptionPane.INFORMATION_MESSAGE );
		
	}
	
	//MODIFICA UN CURSO, LLAMA A CURSODAO PARA BUSCAR EL ID DEL CUPO A MODIFICAR
	public void ModificarCurso(Curso curso) {
		CursoDAO dao = new CursoDAO();
		
		try {
			dao.update(curso);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JOptionPane.showMessageDialog(null , "Curso Modificado!", "Felicidades (?", JOptionPane.INFORMATION_MESSAGE );
		
	}
	
	//VALIDA QUE NO EXISTAN DUPLICADOS EN LA BASE DE DATOS 
	public void ValidarDuplicados(boolean bandera, Curso cur) throws SQLException {
		
		CursoDAO curso = new CursoDAO();
	
		if(!curso.FuncionExistente(this.cupo)) {
			
			if(bandera == false) {
				GuardarCurso(cur);
			}else {
				
				ModificarCurso(cur);
			}
			
		}else {
			JOptionPane.showMessageDialog(null , "Ya existe el Cupo", "ERROR", JOptionPane.INFORMATION_MESSAGE );
		}
	}
	
	public Curso CursoGuardar(int cupo) throws SQLException {
		CursoDAO cursoDao = new CursoDAO();
		return cursoDao.CursoModificar(cupo);
	}
	
	
	//CREA LA TABLA CURSOS
	public void CrearTabla() {
		try {
			CursoDAO.createTable();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void EliminarCurso(int cupo) throws SQLException {
		CursoDAO curDao = new CursoDAO();
		curDao.EliminarCurso(cupo);
		
	}
}
