package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import Proyecto.ProfesorDAO;

public class Profesores extends Persona {
	
	private String cuil;
	private LocalDate fechaIngreso;
	
	public String mostrarInformacion() {	
		return "Nombre: " + super.getNombres().toUpperCase() + "Apellido: " + super.getApellido().toUpperCase() + "CUIL: " + this.cuil;
	}

	
	//CONSTRUCTORES

	public Profesores(String cuil, LocalDate fechaIngreso) {
		super();
		this.cuil = cuil;
		this.fechaIngreso = fechaIngreso;
	}
	
	public Profesores() {
		super();
	}

	public Profesores(Long numeroDocumento, String apellido, String nombres, LocalDate fechaNacimiento,
			String domicilio, String telefono, String correoElectronico, String cuil, LocalDate fechaIngreso) {
		super(numeroDocumento, apellido, nombres, fechaNacimiento, domicilio, telefono, correoElectronico);
		this.cuil = cuil;
		this.fechaIngreso = fechaIngreso;
		// TODO Auto-generated constructor stub
	}
	
	


	public Profesores(Long numeroDocumento, String apellido, String nombres) {
		super(numeroDocumento, apellido, nombres);
	}


	//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Profesores other = (Profesores) obj;
		if (cuil == null) {
			if (other.cuil != null)
				return false;
		} else if (!cuil.equals(other.cuil))
			return false;
		if (fechaIngreso == null) {
			if (other.fechaIngreso != null)
				return false;
		} else if (!fechaIngreso.equals(other.fechaIngreso))
			return false;
		return true;
	}

	//TO STRING
	@Override
	public String toString() {
		return "Profesores [cuil=" + cuil + ", fechaIngreso=" + fechaIngreso + ", numeroDocumento=" + numeroDocumento
				+ ", apellido=" + apellido + ", nombres=" + nombres + ", fechaNacimiento=" + fechaNacimiento
				+ ", domicilio=" + domicilio + ", telefono=" + telefono + ", correoElectronico=" + correoElectronico
				+ ", id = " + this.getId() +"]";
	}
	
	

	//GETTERS Y SETTERS
	public String getCuil() {
		return cuil;
	}

	public void setCuil(String cuil) {
		this.cuil = cuil;
	}
	public LocalDate getFechaIngreso() {
		return fechaIngreso;
	}


	public void setFechaIngreso(LocalDate fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}


	public List<Profesores> MostrarProf() throws SQLException{
		ProfesorDAO dao = new ProfesorDAO();
		
		return dao.DniNomApe();
		
	}
	
	public Profesores DatosProfesorGuardar(Long dni) throws SQLException {
		ProfesorDAO dao = new ProfesorDAO();
		
		return dao.DatosProfeGuardar(dni);
		
	}
	
	public void AlmacenarProfesor(Profesores profe) throws SQLException {
		ProfesorDAO profeDao = new ProfesorDAO(); 
		
		profeDao.insert(profe);
		
	}
	
	public Boolean ValidarProfesor(Long numDoc) {
		ProfesorDAO profeDao = new ProfesorDAO();
		
		try {
			return profeDao.ValidarProfesor(numDoc);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	public long idExtraer(long numDoc) throws SQLException {
		ProfesorDAO profeDao = new ProfesorDAO();
		return profeDao.ExtraerId(numDoc);
	}
	
	public void Modificar(Profesores profe) throws SQLException {
		ProfesorDAO profeDao = new ProfesorDAO();
		
		profeDao.update(profe);
	}
	public void EliminarProfesor(Long dni) throws SQLException {
		ProfesorDAO profeDao = new ProfesorDAO();
		profeDao.EliminarProfesor(dni);
	}
	
}
