package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Proyecto.AlumnoDAO;
import Proyecto.AsignaturaDAO;
import Proyecto.CursoDAO;
import Proyecto.MateriaDAO;
import Proyecto.ProfesorDAO;

public class Asignatura extends BaseModelo {

	protected int codigo;
	protected String nombre;
	protected List<Alumno> listaAlumnos= new ArrayList<Alumno>();
	protected Profesores profesor;
	protected Materia materia;
	protected Curso curso;
	
	//CONSTRUCTORES
	public Asignatura(int codigo, String nombre, List<Alumno> listaAlumnos, Profesores profesor) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.listaAlumnos = listaAlumnos;
		this.profesor = profesor;
	}
	
	public Asignatura(int codigo, String nombre, long Alumno, long Profesor, long materia, long curso) throws SQLException {
		this.codigo = codigo;
		this.nombre = nombre;
		
		ProfesorDAO profesao= new ProfesorDAO();
		List<Profesores> prolist = profesao.getAll();
		for(Profesores A: prolist) {
			if(Profesor == A.getId()) { 
				this.profesor= A;
			}
		}
		AlumnoDAO alumao= new AlumnoDAO();
		List<Alumno> alulist= alumao.getAll();
		for(Alumno A: alulist) {
			if(Alumno == A.getId()) {
				this.listaAlumnos.add(A);
			}
		}
		MateriaDAO mateDao = new MateriaDAO();
		List<Materia> mateList = mateDao.getAll();
		for(Materia a: mateList) {
			if(materia == a.getId()) {
				this.materia = a;
			}
		}
		CursoDAO curDao = new CursoDAO();
		List<Curso> curList = curDao.getAll();
		for(Curso a: curList) {
			if(curso == a.getId()) {
				this.curso = a;
			}
		}
	}
	public void setAlumno(Alumno alu) {
		this.listaAlumnos.add(alu);
	}
	public Asignatura() {
		super();
	}
	
	//GETTERS AND SETTERS
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Alumno> getListaAlumnos() {
		return listaAlumnos;
	}
	public void setListaAlumnos(List<Alumno> listaAlumnos) {
		this.listaAlumnos = listaAlumnos;
	}
	public Profesores getProfesor() {
		return profesor;
	}
	public void setProfesor(Profesores profesor) {
		this.profesor = profesor;
		
	}
	public void AgregarElementoAlumno(Alumno alu) {
		this.listaAlumnos.add(alu);
	}
	public Materia getMateria() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asignatura other = (Asignatura) obj;
		if (profesor == null) {
			if (other.profesor != null)
				return false;
		} else if (!profesor.equals(other.profesor))
			return false;
		if (codigo != other.codigo)
			return false;
		if (listaAlumnos == null) {
			if (other.listaAlumnos != null)
				return false;
		} else if (!listaAlumnos.equals(other.listaAlumnos))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}
	
	//TOSTRING
	@Override
	public String toString() {
		return "Asignatura [codigo=" + codigo + ", nombre=" + nombre + ", listaAlumnos=" + listaAlumnos + ", Profesor="
				+ profesor + "]";
	}
	
	public void Guardar() throws SQLException {
		AsignaturaDAO dao = new AsignaturaDAO();
		for(int i = 0 ; i < this.listaAlumnos.size(); i++) {
			Asignatura aux = new Asignatura();
			
			aux.setCodigo(this.codigo);
			aux.AgregarElementoAlumno(this.listaAlumnos.get(i));
			aux.setNombre(this.nombre);
			aux.setProfesor(this.profesor);
			aux.setMateria(this.materia);
			aux.setCurso(this.curso);
			
			dao.insert(aux);
		}
	}
	
	public void Modificar(List<Long> ids) throws SQLException {
		AsignaturaDAO dao = new AsignaturaDAO();
		for(int i = 0 ; i < this.listaAlumnos.size(); i++) {
			Asignatura aux = new Asignatura();
			
			aux.setCodigo(this.codigo);
			aux.AgregarElementoAlumno(this.listaAlumnos.get(i));
			aux.setNombre(this.nombre);
			aux.setProfesor(this.profesor);
			aux.setMateria(this.materia);
			aux.setCurso(this.curso);
			
			if(ids.size() > i) {
				aux.setId(ids.get(i));
				dao.update(aux);
			}else {
				dao.insert(aux);
			}
		}
	}
	
	
	public void CrearTabla() throws SQLException {
		AsignaturaDAO.createTable();
	}
	
	public List<String> ExtraerCodNombre() throws SQLException{
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		return asigDao.CodNombre();
	}
	
	public Asignatura ExtraerUnaAsignatura(int codAsig) throws SQLException {
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		return asigDao.AsignaturaModificar(codAsig);
	}
	
	public void EliminarAlumAsig(long id) throws SQLException {
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		asigDao.EliminarAsignaturaAlumno(id);
	}
	public Long ExtraerIdsAsignatura(int cod, long idAlu) throws SQLException {
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		return asigDao.ExtraerIdAsignatura(cod, idAlu);
	}
	
	public void EliminarAsignatura(int codAsig) throws SQLException {
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		asigDao.EliminarAsignatura(codAsig);
		
	}

}
