package ar.com.gugler.sgc.modelo;

public interface Administrable {
	
	public boolean admiteInscripciones();
	
}
