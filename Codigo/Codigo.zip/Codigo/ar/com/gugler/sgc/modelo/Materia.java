package ar.com.gugler.sgc.modelo;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

import Proyecto.MateriaDAO;

public class Materia extends Asignatura {
	private int anio;


	//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Materia other = (Materia) obj;
		if (anio != other.anio)
			return false;
		return true;
	}
	
	//TO STRING
	@Override
	public String toString() {
		return "Materia [anio=" + anio + "]";
	}
	
	//GETTERS AND SETTERS
	public int getAnio() {
		return anio;
	}
	public void setAnio(int anio) {
		this.anio = anio;
	}

	
	
	//CONSTRUCTORES
	public Materia(int codigo, String nombre, List<Alumno> listaAlumnos, Profesores profesor, int anio) {
		super(codigo, nombre, listaAlumnos, profesor);
		this.anio = anio;
	}

	public Materia(int anio2) {
		// TODO Auto-generated constructor stub
		this.anio = anio2;
	}

	public Materia() {
		super();
	}

	
	//FUNCIONES
	
	public boolean ValidarFecha(String cadena) {
		try {
			int caden=Integer.parseInt(cadena);
			
			Calendar c = new GregorianCalendar();
			String annio = Integer.toString(c.get(Calendar.YEAR));
			
			int anioActual =Integer.parseInt(annio); 
			
			if(cadena.length()==4 && caden <= anioActual) {
				return true;
			}else {
				return false;
			}
		} catch (NumberFormatException nfe){
			return false;
		}
		
	}
	
	public DefaultListModel<Integer> FechasGuardadas(){
		DefaultListModel<Integer> mate = new DefaultListModel<Integer>();
		MateriaDAO dao = new MateriaDAO();
		
		try {
			List<Materia>fechas = dao.getAll();
			for(Materia i : fechas) {
				
				mate.addElement(i.getAnio());
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		burbuja(mate);
		
		return mate;
		
	} 
	//FUNCION PARA ORDENAR LOS CUPOS A LA HORA DE MOSTRARLO EN EL SCROLL
	public static void burbuja(DefaultListModel<Integer> cupos ){
		int i, j, aux;
	        
	    for(i=0;i<cupos.size()-1;i++) {
	    	for(j=0;j<cupos.size()-i-1;j++) {
	    		if(cupos.get(j+1)<cupos.get(j)){
	    			aux=cupos.get(j+1);
	                cupos.set(j+1, cupos.get(j));
	                cupos.set(j,aux);
	            }
	    	}
	    }
	}
	
	
	public void GuardarMateria(Materia mate) {
		MateriaDAO dao = new MateriaDAO();
		
		try {
			dao.insert(mate);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null , "Guardado!", "ERROR", JOptionPane.INFORMATION_MESSAGE );
		
	}
	
	//MODIFICA UN CURSO, LLAMA A CURSODAO PARA BUSCAR EL ID DEL CUPO A MODIFICAR
	public void ModificarMateria(Materia mate) {
		MateriaDAO dao = new MateriaDAO();
			
		try {
			dao.update(mate);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JOptionPane.showMessageDialog(null , "Materia Modificado!", "Felicidades (?", JOptionPane.INFORMATION_MESSAGE );
			
	}
	
	//VALIDA QUE NO EXISTAN DUPLICADOS EN LA BASE DE DATOS Y APARTE LOS GUARDA, SEGUN SEA A MODIFICAR O ALMACENAR
	public void ValidarDuplicados(boolean bandera, Materia mate) throws SQLException {
		MateriaDAO dao = new MateriaDAO();
	
		if(dao.FuncionExistente(this.anio) == true) {
			if(bandera == false) {
				GuardarMateria(mate);
			}else {
				ModificarMateria(mate);
			}
		}else {
			JOptionPane.showMessageDialog(null , "Ya existe el anio", "ERROR", JOptionPane.INFORMATION_MESSAGE );
		}
	}
	
	public Materia MateriaGuardar(int anio) throws SQLException {
		MateriaDAO mateDao = new MateriaDAO();
		return mateDao.MateriaModificar(anio);
	}
	
	public void CrearTabla() {
		try {
			MateriaDAO.createTable();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void EliminarMateria(int anio) throws SQLException {
		MateriaDAO mateDao = new MateriaDAO();
		mateDao.EliminarMateria(anio);
		
	}
	
	
}
