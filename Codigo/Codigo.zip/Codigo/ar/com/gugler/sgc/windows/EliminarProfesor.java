package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import ar.com.gugler.sgc.modelo.Profesores;

@SuppressWarnings("serial")
public class EliminarProfesor extends JFrame {

	private JPanel contentPane;
	private String user;
	private JTextField textDni;
	private JTextField textField;
	private JComboBox<String> boxProfesor;
	private JButton btnVolver;
	private JButton btnModificar;
	private final Action actionVolver = new Volver();
	private final Action actionModificar = new ElimProfesor();
	private final Action actionBuscar = new BuscarDNI();

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarProfesor frame = new EliminarProfesor(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public EliminarProfesor(String usuario) {
		user= usuario;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		contentPane.setBackground(Color.white);
		
		//LABELS
		JLabel lblProfesor = new JLabel("Profesores:");
		lblProfesor.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblProfesor.setBounds(145, 28, 98, 22);
		contentPane.add(lblProfesor);
		
		JLabel lblBuscarDni = new JLabel("Buscar por DNI:");
		lblBuscarDni.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblBuscarDni.setBounds(145, 104, 119, 14);
		contentPane.add(lblBuscarDni);
		
		//CHECKBOX
		boxProfesor = new JComboBox<String>();
		boxProfesor.setFont(new Font("Dialog", Font.BOLD, 11));
		boxProfesor.setBounds(151, 61, 134, 22);
		contentPane.add(boxProfesor);
		
		//TEXTFIELD
		textField = new JTextField();
		textField.setText("Usuario: <dynamic>");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Rockwell", Font.BOLD, 13));
		textField.setEditable(false);
		textField.setColumns(10);
		textField.setBorder(null);
		textField.setBackground(Color.WHITE);
		textField.setBounds(287, 11, 137, 20);
		contentPane.add(textField);
		contentPane.add(textField);
		
		//AGREGO USUARIO EN LA ESQUINA DE LA VENTANA.
		String firstLtr = usuario.substring(0, 1);
	    String restLtrs = usuario.substring(1, usuario.length());
	    firstLtr = firstLtr.toUpperCase();
	    usuario = firstLtr + restLtrs;
		textField.setText("Usuario: " + usuario);
		
		textDni = new JTextField();
		textDni.setFont(new Font("Dialog", Font.BOLD, 11));
		textDni.setBounds(153, 129, 132, 20);
		contentPane.add(textDni);
		textDni.setColumns(10);
		ValidacionNumeros(textDni);

		//BOTTONS
		JButton btnBuscar = new JButton("New button");
		btnBuscar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnBuscar.setAction(actionBuscar);
		btnBuscar.setBounds(175, 160, 89, 23);
		contentPane.add(btnBuscar);
		
		btnVolver = new JButton("");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 214, 89, 23);
		contentPane.add(btnVolver);
		
		btnModificar = new JButton("");
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setAction(actionModificar);
		btnModificar.setBounds(335, 214, 89, 23);
		contentPane.add(btnModificar);
		
		try {
			MostrarProfesores();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void MostrarProfesores() throws SQLException {
		Profesores prof = new Profesores();
		List<Profesores> aux = new ArrayList<>();
		
		aux = prof.MostrarProf();
		
		boxProfesor.addItem("Profesores");
		
		for(int i = 0; i < aux.size(); i++) {
			
			prof = aux.get(i);
			
			String str = prof.getApellido() + " " + prof.getNombres() + " " + prof.getNumeroDocumento();
			
			boxProfesor.addItem(str);
			
		}
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
		public void keyTyped(KeyEvent e ) {
	    	char c = e.getKeyChar();

	        if((!Character.isDigit(c))) {
	        	e.consume();
	        }
	     }
	    });
	}
	
	//EXTRAIGO SOLAMENTE EL DNI
	public Long SepararDatosProfesor(String prof) {
		
		String[] a = prof.split(" ");
		
		return Long.parseLong(a[a.length-1]);
		
	}
	
	//FUNCION BUSCAR, SEGUN UN DNI BUSCO A VER SI EXISTE EN LA BD
	private class BuscarDNI extends AbstractAction {
		public BuscarDNI() {
			putValue(NAME, "Buscar");
		}
		public void actionPerformed(ActionEvent e) {
			if(!textDni.getText().isEmpty()) {
				long dni = Long.parseLong(textDni.getText());
				
				for(int i = 1; i < boxProfesor.getItemCount() ; i++) {
					if(dni == SepararDatosProfesor(boxProfesor.getItemAt(i))) {
						boxProfesor.setSelectedIndex(i);
						return;
					}
				}
				JOptionPane.showMessageDialog(null , "Profesor no encontrado!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}else {
				JOptionPane.showMessageDialog(null , "No seleccionaste ningun DNI!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
	
	private class Volver extends AbstractAction {
		public Volver() {
			putValue(NAME, "Vovler");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarProfesores ventana = new GestionarProfesores(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	//FUNCION ELIMINAR PROFESOR, SEGUN UN DNI SE ELIMINA.
	private class ElimProfesor extends AbstractAction {
		public ElimProfesor() {
			putValue(NAME, "Eliminar");
		}
		public void actionPerformed(ActionEvent e) {
			if(!boxProfesor.getSelectedItem().equals("Profesores")) {
				Long dni = SepararDatosProfesor((String) boxProfesor.getSelectedItem());
				
				Profesores profe = new Profesores();
				try {
					profe.EliminarProfesor(dni);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null , "Profesor: " + boxProfesor.getSelectedItem() + " eliminado!", "Error", JOptionPane.INFORMATION_MESSAGE );
				boxProfesor.removeAllItems();
				try {
					MostrarProfesores();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}else {
				JOptionPane.showMessageDialog(null , "Seleccionar un profesor!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
}
