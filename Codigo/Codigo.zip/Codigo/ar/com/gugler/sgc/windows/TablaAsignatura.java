package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Proyecto.AsignaturaDAO;
import ar.com.gugler.sgc.modelo.Asignatura;
import javax.swing.JComboBox;
import javax.swing.JList;


@SuppressWarnings("serial")
public class TablaAsignatura extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private String user;
	private final Action actionVolver = new FuncionVolver();
	private JTable tableAsignatura;
	private JComboBox<String> cBCodAsignatura;
	private List<Asignatura> asignatura;
	private JList<String> listaAlumnos;
	/**
	 * Launch the application.
	 */
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TablaAsignatura frame = new TablaAsignatura(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TablaAsignatura(String usuario) {
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 698, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblAlumnos = new JLabel("Lista Alumnos");
		lblAlumnos.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblAlumnos.setBounds(511, 131, 119, 25);
		contentPane.add(lblAlumnos);
		
		JLabel lblTitulo = new JLabel("Tabla de Asignaturas");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(521, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		//BOTTONS
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(25, 317, 89, 23);
		contentPane.add(btnVolver);
		
		//LIST
		JScrollPane PanelDeAsignatura = new JScrollPane();
		PanelDeAsignatura.setBounds(10, 167, 463, 108);
		contentPane.add(PanelDeAsignatura);
		PanelDeAsignatura.setBackground(Color.white);
		
		JScrollPane scrollAlumnos = new JScrollPane();
		scrollAlumnos.setBounds(521, 167, 119, 151);
		contentPane.add(scrollAlumnos);
		
		listaAlumnos = new JList<String>();
		listaAlumnos.setFont(new Font("Rockwell", Font.BOLD, 11));
		scrollAlumnos.setViewportView(listaAlumnos);
		
		//TABLA
		tableAsignatura = new JTable();
		tableAsignatura.setFont(new Font("Rockwell", Font.BOLD, 11));
		tableAsignatura.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codigo Asignatura", "Nombre Asigntura", "Profesor", "Materia", "Curso"
			}
		) {
			@SuppressWarnings("rawtypes")
			Class[] columnTypes = new Class[] {
				Object.class, Object.class, Object.class, Object.class, Object.class
			};
			@SuppressWarnings({ "unchecked", "rawtypes" })
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		tableAsignatura.getColumnModel().getColumn(0).setResizable(false);
		tableAsignatura.getColumnModel().getColumn(0).setPreferredWidth(109);
		tableAsignatura.getColumnModel().getColumn(1).setResizable(false);
		tableAsignatura.getColumnModel().getColumn(1).setPreferredWidth(115);
		tableAsignatura.getColumnModel().getColumn(2).setResizable(false);
		tableAsignatura.getColumnModel().getColumn(3).setResizable(false);
		tableAsignatura.getColumnModel().getColumn(4).setResizable(false);
		tableAsignatura.setRowSelectionAllowed(false);
		PanelDeAsignatura.setViewportView(tableAsignatura);
		
		//CHECKBOX
		cBCodAsignatura = new JComboBox<String>();
		cBCodAsignatura.setFont(new Font("Rockwell", Font.BOLD, 11));
		cBCodAsignatura.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent ie) {
				CargarAlumnosAsignatura();
			}
		});
		cBCodAsignatura.setBounds(501, 95, 157, 22);
		contentPane.add(cBCodAsignatura);
		cBCodAsignatura.setBackground(Color.white);
		
		try {
			CargarDatosTabla();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//MUESTRO TODOS LOS DATOS DE LA ASIGNATURA EN UNA TABLA, EXCEPTO LOS ALUMNOS.
	private void CargarDatosTabla() throws SQLException {
		int numCols = tableAsignatura.getModel().getColumnCount();
		AsignaturaDAO asigDao = new AsignaturaDAO();
		
		asignatura = asigDao.ExtraerTodasLasAsignaturas();
		
		for(Asignatura a: asignatura) {
			Object [] fila = new Object[numCols];
			
			fila[0] = a.getCodigo();
			fila[1] = a.getNombre();
			fila[2] = a.getProfesor().getNombres();
			fila[3] = a.getMateria().getAnio();
			fila[4] = a.getCurso().getCupo();
			
			((DefaultTableModel) tableAsignatura.getModel()).addRow(fila);
			
			numCols++;
		}
		CargarDatosBox();
	}
	
	//CARGO TODOS LOS CODIGOS DE ASIGNATURA EN UN CHECKBOX, PARA MOSTRAR LOS ALUMNOS DE DICHA ASIGNATURA
	private void CargarDatosBox() {
		cBCodAsignatura.addItem("Codigos Asignaturas");
		for(int i = 0; i < asignatura.size() ; i++) {
			cBCodAsignatura.addItem("" + asignatura.get(i).getCodigo());
		}
	}
	
	//MUESTRO EN UN LIST TODOS LOS ALUMNOS DE DICHA ASIGNATURA SELECCIONADA.
	private void CargarAlumnosAsignatura() {
		if(!cBCodAsignatura.getSelectedItem().equals("Codigos Asignaturas")) {
			int codAsignatura = Integer.parseInt((String) cBCodAsignatura.getSelectedItem());
			
			for(int i = 0 ; i < asignatura.size() ; i++) {
				if(asignatura.get(i).getCodigo() == codAsignatura) {
					DefaultListModel<String> auxiliarLista = new DefaultListModel<String>();
					listaAlumnos.setModel(auxiliarLista);
					for(int x = 0 ; x < asignatura.get(i).getListaAlumnos().size() ; x++) {
						auxiliarLista.add(x, asignatura.get(i).getListaAlumnos().get(x).getNumeroDocumento() + " " + asignatura.get(i).getListaAlumnos().get(x).getNombres() + " " +
								asignatura.get(i).getListaAlumnos().get(x).getApellido());
					}
					listaAlumnos.setModel(auxiliarLista);
				}
			}
		}
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			AsignaturaWindow ventana = new AsignaturaWindow(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
