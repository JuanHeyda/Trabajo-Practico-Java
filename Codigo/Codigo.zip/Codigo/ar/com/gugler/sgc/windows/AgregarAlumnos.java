package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;

import ar.com.gugler.sgc.modelo.Alumno;

import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

@SuppressWarnings("serial")
public class AgregarAlumnos extends JFrame {
	
	private JPanel contentPane;
	private JTextField textUsuario;
	private JTextField textNombre;
	private JTextField textApellido;
	private JTextField textDNI;
	private JTextField textLegajo;
	private JTextField textDomicilio;
	private JTextField textCorreoElectronico;
	private JTextField textTelefono;
	boolean banderaGuardar = false;
	private final Action action = new GuardarModificarAlum();
	private JDateChooser dateCalendario = new JDateChooser();
	private final Action action_1 = new FuncionVolver();
	private String user;
	private Alumno alumModificar;
	private boolean modificar = false;
	JButton btnAceptar = new JButton("Aceptar");
	
	/**
	 * Launch the application.
	 */
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarAlumnos frame = new AgregarAlumnos(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarAlumnos(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);

		JLabel lblDatosDeAlumno = new JLabel("Agregar Alumno");
		lblDatosDeAlumno.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblDatosDeAlumno.setBounds(161, 23, 176, 23);
		contentPane.add(lblDatosDeAlumno);
		
		JLabel lblNombre = new JLabel("Nombre/s:");
		lblNombre.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblNombre.setBounds(223, 74, 66, 14);
		contentPane.add(lblNombre);
		
		JLabel lblApellidos = new JLabel("Apellido/s\r\n:");
		lblApellidos.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblApellidos.setBounds(223, 105, 66, 14);
		contentPane.add(lblApellidos);
		
		JLabel lblDni = new JLabel("DNI\r\n:");
		lblDni.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblDni.setBounds(261, 134, 66, 14);
		contentPane.add(lblDni);
		
		JLabel lblLegajo = new JLabel("Legajo\r\n:");
		lblLegajo.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblLegajo.setBounds(243, 198, 56, 14);
		contentPane.add(lblLegajo);
		
		JLabel lblDomicilio = new JLabel("Domicilio\r\n:");
		lblDomicilio.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblDomicilio.setBounds(223, 229, 66, 14);
		contentPane.add(lblDomicilio);
		
		JLabel lblTelefono = new JLabel("Telefono\r\n:");
		lblTelefono.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblTelefono.setBounds(233, 260, 56, 14);
		contentPane.add(lblTelefono);
		
		JLabel lblCorreoElectronico = new JLabel("Correo Electronico\r\n:");
		lblCorreoElectronico.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblCorreoElectronico.setBounds(174, 291, 115, 14);
		contentPane.add(lblCorreoElectronico);
		
		JLabel lblFechaDeNacimiento = new JLabel("Fecha de Nacimiento:");
		lblFechaDeNacimiento.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblFechaDeNacimiento.setBounds(158, 165, 137, 14);
		contentPane.add(lblFechaDeNacimiento);
		
		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
        textUsuario.setText("Usuario: " + usuario);
        user=usuario;
		
		textNombre = new JTextField();
		textNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textNombre.setFont(new Font("Rockwell", Font.BOLD, 11));
		textNombre.setColumns(10);
		textNombre.setBounds(299, 72, 86, 20);
		contentPane.add(textNombre);
		ValidacionLetras(textNombre);
		
		textApellido = new JTextField();
		textApellido.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textApellido.setFont(new Font("Rockwell", Font.BOLD, 11));
		textApellido.setColumns(10);
		textApellido.setBounds(299, 103, 86, 20);
		contentPane.add(textApellido);
		ValidacionLetras(textApellido);
		
		textDNI = new JTextField();
		textDNI.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textDNI.setFont(new Font("Rockwell", Font.BOLD, 11));
		textDNI.setColumns(10);
		textDNI.setBounds(299, 134, 86, 20);
		contentPane.add(textDNI);
		ValidacionNumeros(textDNI);
		
		textLegajo = new JTextField();
		textLegajo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textLegajo.setFont(new Font("Rockwell", Font.BOLD, 11));
		textLegajo.setColumns(10);
		textLegajo.setBounds(299, 196, 86, 20);
		contentPane.add(textLegajo);
		
		textDomicilio = new JTextField();
		textDomicilio.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textDomicilio.setFont(new Font("Rockwell", Font.BOLD, 11));
		textDomicilio.setColumns(10);
		textDomicilio.setBounds(299, 227, 86, 20);
		contentPane.add(textDomicilio);
		dateCalendario.getCalendarButton().setFont(new Font("Rockwell", Font.PLAIN, 11));
		
		dateCalendario.setBounds(299, 165, 114, 20);
		contentPane.add(dateCalendario);

		textCorreoElectronico = new JTextField();
		textCorreoElectronico.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textCorreoElectronico.setFont(new Font("Rockwell", Font.BOLD, 11));
		textCorreoElectronico.setColumns(10);
		textCorreoElectronico.setBounds(299, 289, 86, 20);
		contentPane.add(textCorreoElectronico);
		
		textTelefono = new JTextField();
		textTelefono.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textTelefono.setFont(new Font("Rockwell", Font.BOLD, 11));
		textTelefono.setColumns(10);
		textTelefono.setBounds(299, 258, 86, 20);
		contentPane.add(textTelefono);
		ValidacionNumeros(textTelefono);
		btnAceptar.setFont(new Font("Rockwell", Font.BOLD, 11));
		
		//BOTONES
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAceptar.setAction(action);
		btnAceptar.setBounds(296, 326, 89, 23);
		contentPane.add(btnAceptar);
		btnAceptar.setEnabled(false);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnVolver.setAction(action_1);
		btnVolver.setBounds(10, 325, 89, 23);
		contentPane.add(btnVolver);
		
	}
	
	//ASIGNO LOS DATOS PARA MODIFICAR UN ALUMNO, EL ALUMNO VIENE DE LA VENTANA MODIFICAR ALUMNO
	public void AlumnoModificar(Alumno alum) {
		this.alumModificar = alum;
		modificar = true;

		ZoneId defaultZoneId = ZoneId.systemDefault();
		Date date = Date.from(alumModificar.getFechaNacimiento().atStartOfDay(defaultZoneId).toInstant());
		
		textNombre.setText(alumModificar.getNombres());
		textApellido.setText(alumModificar.getApellido());
		textDNI.setText(alumModificar.getNumeroDocumento().toString());
		textDomicilio.setText(alumModificar.getDomicilio());
		textTelefono.setText(alumModificar.getTelefono());
		textCorreoElectronico.setText(alumModificar.getCorreoElectronico());
		textLegajo.setText(alumModificar.getLegajo());
		dateCalendario.setDate(date);
		
	}
	
	//VALIDO QUE SEAN SOLAMENTE LETRAS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionLetras(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e ) {
				char c = e.getKeyChar();

				if((!Character.isAlphabetic(c))) {
					e.consume();
			    }
			}
		});
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e ) {
				char c = e.getKeyChar();
		        if((!Character.isDigit(c))) {
		        	e.consume();
		        }
			}
		});
	}
	
	//COMPRUEBA QUE TODOS LOS DATOS ESTEN CARGADOS ASI SE HABILITA EL BOTON GUARDAR
	private void ComprobarBotonGuardar() {
		if(	!textNombre.getText().isEmpty() && !textApellido.getText().isEmpty() && 
			!textDNI.getText().isEmpty() && !textLegajo.getText().isEmpty()
			&& !textDomicilio.getText().isEmpty() && textCorreoElectronico.getText().indexOf('@')!=-1
					&& !textCorreoElectronico.getText().isEmpty() && !textTelefono.getText().isEmpty() && banderaGuardar == false){
					
			btnAceptar.setEnabled(true);
			banderaGuardar = true;
		}
	}
	
	//BOTON GUARDAR, VERIFICO ADENTRO SI ES QUE ESTOY GUARDANDO O MODIFICANDO UN ALUMNO, SEGUN UNA BANDERA LLAMADA MODIFICAR.
	private class GuardarModificarAlum extends AbstractAction {
		public GuardarModificarAlum() {
			putValue(NAME, "Guardar");
		}
		public void actionPerformed(ActionEvent e) {
			if(banderaGuardar == true) {
				Alumno alumno = new Alumno();
				try {
					alumno.creartabla();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
	
				Date date= dateCalendario.getDate();
				Alumno alum = new Alumno(Long.parseLong(textDNI.getText()),textApellido.getText(),textNombre.getText(),
						  dateCalendario.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
						  textDomicilio.getText(), textTelefono.getText(),textCorreoElectronico.getText(),textLegajo.getText());
			
				if(date!=null) {
					if(modificar == false) {
						try {	
							if(alum.Validacion()){
								alum.GenerarAlumno(alum);
							}
						}catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else if(modificar == true) {
						try {
							long id = alum.idExtraer(alumModificar.getNumeroDocumento());
							alum.setId(id);
							alum.Modificar(alum);

							modificar=false;
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					textNombre.setText("");
					textApellido.setText("");
					textDNI.setText("");
					textLegajo.setText("");
					textDomicilio.setText("");
					textCorreoElectronico.setText("");
					textTelefono.setText("");
					
				}else {
					JOptionPane.showMessageDialog(null , "Agregue una fecha", "ERROR", JOptionPane.INFORMATION_MESSAGE );
				}
			}
		}
	}
	
	//BOTON VOLVER
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAlumnos ventana = new GestionarAlumnos(user);	
			ventana.setVisible(true);
			dispose();	
		}
	}
	}

