package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import Proyecto.AsignaturaDAO;
import Proyecto.ProfesorDAO;
import ar.com.gugler.sgc.modelo.Alumno;
import ar.com.gugler.sgc.modelo.Asignatura;
import ar.com.gugler.sgc.modelo.Curso;
import ar.com.gugler.sgc.modelo.Materia;
import ar.com.gugler.sgc.modelo.Profesores;

import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


@SuppressWarnings("serial")
public class AgregarAsignatura extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private String user;
	private final Action actionVolver = new FuncionVolver();
	private JTextField textFieldCodigo;
	private JTextField textFieldNombre;
	private final Action actionCargarAlumno = new CargaAlum();
	private final Action actionGuardar = new FuncionGuardar();
	private JList<String> listaDeAlumnos;
	private JComboBox<String> boxAlumnos;
	private JComboBox<String> boxProfesor;
	private JComboBox<String> boxMateria;
	private JComboBox<String> boxCurso;
	private JButton btnGuardar;
	private boolean banderaGuardar = false;
	private DefaultListModel<String> list = new DefaultListModel<>();
	private Asignatura asigModificar;
	private boolean modificar = false;
	
	/**
	 * Launch the application.
	 */
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarAsignatura frame = new AgregarAsignatura(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarAsignatura(String usuario) {
		
		try {
			ProfesorDAO.createTable();
			Asignatura asig = new Asignatura();
			asig.CrearTabla();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//Jlabels
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblCodigo = new JLabel("Codigo:");
		lblCodigo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCodigo.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblCodigo.setBounds(211, 83, 60, 14);
		contentPane.add(lblCodigo);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNombre.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblNombre.setBounds(211, 123, 60, 14);
		contentPane.add(lblNombre);
		
		JLabel lblCurso = new JLabel("Curso:");
		lblCurso.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCurso.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblCurso.setBounds(211, 164, 60, 14);
		contentPane.add(lblCurso);
		
		JLabel lblMateria = new JLabel("Materia:");
		lblMateria.setHorizontalAlignment(SwingConstants.RIGHT);
		lblMateria.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblMateria.setBounds(211, 204, 60, 14);
		contentPane.add(lblMateria);
		
		JLabel lblProfesor = new JLabel("Profesor:");
		lblProfesor.setHorizontalAlignment(SwingConstants.RIGHT);
		lblProfesor.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblProfesor.setBounds(211, 243, 60, 14);
		contentPane.add(lblProfesor);
		
		JLabel lblAlumno = new JLabel("Alumno:");
		lblAlumno.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAlumno.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblAlumno.setBounds(211, 283, 60, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblListaAlum = new JLabel("Lista Alumnos\r\n");
		lblListaAlum.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblListaAlum.setBounds(10, 144, 99, 14);
		contentPane.add(lblListaAlum);
		
		JLabel lblTituloAsignatura = new JLabel("Agregar Asignatura");
		lblTituloAsignatura.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTituloAsignatura.setBounds(161, 23, 176, 23);
		contentPane.add(lblTituloAsignatura);
		
		//TEXT FIELD
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		textFieldCodigo = new JTextField();
		textFieldCodigo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		textFieldCodigo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		
		textFieldCodigo.setFont(new Font("Rockwell", Font.BOLD, 11));
		textFieldCodigo.setBounds(281, 80, 159, 20);
		contentPane.add(textFieldCodigo);
		textFieldCodigo.setColumns(10);
		ValidacionNumeros(textFieldCodigo);
		
		textFieldNombre = new JTextField();
		textFieldNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textFieldNombre.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textFieldNombre.setFont(new Font("Rockwell", Font.BOLD, 11));
		textFieldNombre.setColumns(10);
		textFieldNombre.setBounds(281, 120, 159, 20);
		contentPane.add(textFieldNombre);
		
		//CHECKBOX
		boxCurso = new JComboBox<String>();
		boxCurso.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				ComprobarBotonGuardar();
			}
		});
		boxCurso.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxCurso.setBounds(281, 160, 159, 20);
		contentPane.add(boxCurso);
		
		boxMateria = new JComboBox<String>();
		boxMateria.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				ComprobarBotonGuardar();
			}
		});
		boxMateria.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxMateria.setBounds(281, 200, 159, 20);
		contentPane.add(boxMateria);
		
		JScrollPane scrollAlumnos = new JScrollPane();
		scrollAlumnos.setBounds(26, 170, 114, 133);
		contentPane.add(scrollAlumnos);
		
		listaDeAlumnos = new JList<String>();
		listaDeAlumnos.setFont(new Font("Dialog", Font.BOLD, 11));
		listaDeAlumnos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					RemoverAlumnoLista();
				}
			}
		});
		scrollAlumnos.setViewportView(listaDeAlumnos);
		
		boxAlumnos = new JComboBox<String>();
		boxAlumnos.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxAlumnos.setBounds(281, 280, 159, 20);
		contentPane.add(boxAlumnos);
		
		boxProfesor = new JComboBox<String>();
		boxProfesor.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				ComprobarBotonGuardar();
			}
		});
		boxProfesor.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxProfesor.setBounds(281, 240, 159, 20);
		contentPane.add(boxProfesor);
		
		//BOTTONS
		JButton btnCargarAlumno = new JButton("");
		btnCargarAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnCargarAlumno.setAction(actionCargarAlumno);
		btnCargarAlumno.setBounds(290, 317, 139, 23);
		contentPane.add(btnCargarAlumno);
		
		btnGuardar = new JButton("");
		btnGuardar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnGuardar.setAction(actionGuardar);
		btnGuardar.setBounds(162, 317, 89, 23);
		contentPane.add(btnGuardar);
		btnGuardar.setEnabled(false);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(36, 317, 89, 23);
		contentPane.add(btnVolver);
		
		MostrarMateria();
		MostrarCurso();
		try {
			MostrarAlumnos();
			MostrarProfesores();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD (CUPOS)
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
	    public void keyTyped(KeyEvent e ) {

	    	char c = e.getKeyChar();

	        if((!Character.isDigit(c))) {
	        	e.consume();
	        }
	     }
	    });
	}
	
	//COMPRUEBO QUE TODOS LOS DATOS ESTEN LLENOS ASI SE ACTIVA EL BOTON DE GUARDAR
	private void ComprobarBotonGuardar() {
		
		if(!textFieldCodigo.getText().isEmpty() && !textFieldNombre.getText().isEmpty() && !boxCurso.getSelectedItem().equals("Cupos") && !boxMateria.getSelectedItem().equals("Años") 
				&& list.size() != 0 && !boxProfesor.getSelectedItem().equals("Profesores") && banderaGuardar == false) {
			
			btnGuardar.setEnabled(true);
			banderaGuardar = true;
		}
	}
	
	//MUESTRO TODAS LAS MATERIAS EN UN CHECKBOX
	private void MostrarMateria() {
		Materia mate = new Materia();
		DefaultListModel<Integer> fechas = new DefaultListModel<Integer>(); 
		
		fechas = mate.FechasGuardadas();
		boxMateria.addItem("Años");
		
		for(int i = 0 ; i < fechas.getSize(); i ++) {
			boxMateria.addItem(""+fechas.get(i));
		}
		
	}
	
	//MUESTRO TODOS LOS CURSOS EN UN CHECKBOX
	private void MostrarCurso() {
		Curso curso = new Curso();
		DefaultListModel<Integer> cupos = new DefaultListModel<Integer>();
		
		cupos = curso.CursosGuardados();
		boxCurso.addItem("Cupos");
		
		for(int i = 0; i< cupos.getSize(); i ++) {
			boxCurso.addItem(""+cupos.get(i));
		}
		
	}
	
	//MUESTRO TODOS LOS ALUMNOS EN UN CHECKBOX
	public void MostrarAlumnos() throws SQLException {
		Alumno alu = new Alumno();
		List<Alumno> datos = new ArrayList<>();
		datos = alu.GetNombreBD();
		
		boxAlumnos.addItem("Alumnos");
		for(int i = 0 ; i < datos.size(); i++) {
			alu = datos.get(i);
			String str = alu.getApellido() + " " + alu.getNombres() + " " + alu.getNumeroDocumento();
			boxAlumnos.addItem(str);
		}
	}
	
	//MUESTRO TODOS LOS PROFESORES EN UN CHECKBOX
	public void MostrarProfesores() throws SQLException {
		Profesores prof = new Profesores();
		List<Profesores> aux = new ArrayList<>();
		
		aux = prof.MostrarProf();
		
		boxProfesor.addItem("Profesores");
		for(int i = 0; i < aux.size(); i++) {
			prof = aux.get(i);
			
			String str = prof.getApellido() + " " + prof.getNombres() + " " + prof.getNumeroDocumento();
			boxProfesor.addItem(str);
		}
	}
	
	//COMPRUEBO QUE NO SE PUEDA AGREGAR UN MISMO ALUMNO 2 VECES A LA LISTA
	public boolean ComprobarGuardado() {
		for(int i = 0 ; i < list.size() ; i ++) {
			if(boxAlumnos.getSelectedItem().equals(list.get(i))) {
				return true;
			}
		}
		
		return false;
	}
	
	//CARGO LOS ALUMNOS AL SCROLL
	public void CargarScroll() throws SQLException {
		
		if(boxAlumnos.getSelectedItem().equals("Alumnos")) {
			JOptionPane.showMessageDialog(null , "Seleccione un Alumno para agregar!", "Error", JOptionPane.INFORMATION_MESSAGE );
		}else if(ComprobarGuardado() == true) {
			JOptionPane.showMessageDialog(null , "Alumno ya guardado en la lista!", "Error", JOptionPane.INFORMATION_MESSAGE );
		}else {
			if(!boxCurso.getSelectedItem().equals("Cupos")) {
				Long aux = Long.parseLong((String) boxCurso.getSelectedItem());
				
				if(list.size() < aux) {
					listaDeAlumnos.removeAll();
					list.addElement((String) boxAlumnos.getSelectedItem());
					listaDeAlumnos.setModel(list);
					ComprobarBotonGuardar();
				}else {
					JOptionPane.showMessageDialog(null , "Cupo de alumnos completo para dicho curso!", "Error", JOptionPane.INFORMATION_MESSAGE );
				}
			}else {
				JOptionPane.showMessageDialog(null , "Seleccione un Curso para poder agregar un alumno!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
	//REMUEVO UN ALUMNO DE LA LISTA.
	public void RemoverAlumnoLista() {
		listaDeAlumnos.removeAll();
		list.remove(listaDeAlumnos.getSelectedIndex());
		listaDeAlumnos.setModel(list);
	}
	
	//SEPARO LOS DATOS DE LOS ALUMNOS, PARA SACAR SOLAMENTE LOS DNI
	public List<Long> SepararDatosAlumnos() {
		List<Long> aux = new ArrayList<>();
		
		for(int i = 0; i < list.getSize(); i++) {
			String[] a = list.get(i).split(" ");
			aux.add(Long.parseLong(a[a.length-1]));
		}
		return aux;
	}
	
	//SEPARO LOS DATOS DE LOS PROFESORES, PARA SACAR SOLAMENTE EL DNI
	public Long SepararDatosProfesor(String prof) {
		String[] a = prof.split(" ");
		
		return Long.parseLong(a[a.length-1]);
	}

	//ASIGNO TODOS LOS DATOS EN LOS TEXTFIELDE Y CHECKBOX PARA PODER MODIFICARLO 
	public void AsignaturaModificar(Asignatura asig) throws SQLException {
		modificar = true;
		this.asigModificar = new Asignatura();
		this.asigModificar = asig;
		
		textFieldCodigo.setText(this.asigModificar.getCodigo() + "");
		textFieldNombre.setText(this.asigModificar.getNombre());
		for(int i = 1 ; i < boxCurso.getItemCount() ; i ++){
			if(Integer.parseInt(boxCurso.getItemAt(i)) == this.asigModificar.getCurso().getCupo()) {
				boxCurso.setSelectedIndex(i);
			}
		}
		for(int i = 1 ; i < boxMateria.getItemCount() ; i ++) {
			if(Integer.parseInt(boxMateria.getItemAt(i)) == this.asigModificar.getMateria().getAnio()) {
				boxMateria.setSelectedIndex(i);
			}
		}
		for(int i = 1 ; i < boxProfesor.getItemCount() ; i ++) {
			if(this.asigModificar.getProfesor().getNumeroDocumento().equals(SepararDatosProfesor(boxProfesor.getItemAt(i)))) {
				boxProfesor.setSelectedIndex(i);
			}
		}
		for(int i = 0 ; i < this.asigModificar.getListaAlumnos().size() ; i ++) {
			list.addElement(this.asigModificar.getListaAlumnos().get(i).getApellido() + " " + this.asigModificar.getListaAlumnos().get(i).getNombres() + " " + this.asigModificar.getListaAlumnos().get(i).getNumeroDocumento());
		}
		listaDeAlumnos.setModel(list);
		ComprobarBotonGuardar();
	}
	
	//FUNCION PARA GUARDAR O MODIFICAR LA ASIGNATURA, DEPENDIENDO DE COMO ESTE LA BANDERA modificar PARA PODER MODIFICARLA O GUARDARLA
	private class FuncionGuardar extends AbstractAction {
		public FuncionGuardar() {
			putValue(NAME, "Guardar");
		}
		public void actionPerformed(ActionEvent e) {
			if(banderaGuardar == true) {
				Asignatura asignatura = new Asignatura();
				AsignaturaDAO asigDao = new AsignaturaDAO();
				
				Alumno alum = new Alumno();
				Profesores profeGuardar = new Profesores();
				Materia mate = new Materia();
				Curso curso = new Curso();
				
				int cupo = Integer.parseInt((String) boxCurso.getSelectedItem());
				int anio = Integer.parseInt((String) boxMateria.getSelectedItem());
				
				List<Alumno> aluGuardar = new ArrayList<>();
				
				try {
					aluGuardar = alum.DatosAlumnosGuardar(SepararDatosAlumnos());
					profeGuardar = profeGuardar.DatosProfesorGuardar(SepararDatosProfesor((String) boxProfesor.getSelectedItem()));
					mate = mate.MateriaGuardar(anio);
					curso = curso.CursoGuardar(cupo);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				asignatura.setCodigo(Integer.parseInt(textFieldCodigo.getText()));
				asignatura.setNombre(textFieldNombre.getText());
				asignatura.setListaAlumnos(aluGuardar);
				asignatura.setProfesor(profeGuardar);
				asignatura.setMateria(mate);
				asignatura.setCurso(curso);
				
				if(modificar == false) {
					try {
						if(asigDao.ValidarAsignatura(asignatura.getCodigo())){
							asignatura.Guardar();
						}else {
							JOptionPane.showMessageDialog(null , "Asignatura ya guardada!", "Error", JOptionPane.INFORMATION_MESSAGE );
						}
					} catch (NumberFormatException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}else {
					modificar = false;
					List <Long> idsAsig = new ArrayList<Long>();
					
					for(int i = 0 ; i < asigModificar.getListaAlumnos().size() ; i ++) {
						try {
							idsAsig.add(asignatura.ExtraerIdsAsignatura(asigModificar.getCodigo(), asigModificar.getListaAlumnos().get(i).getId()));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					
					if(asigModificar.getListaAlumnos().size() > asignatura.getListaAlumnos().size()) {
						for(int i = 0; i < (asigModificar.getListaAlumnos().size() - asignatura.getListaAlumnos().size()) ; i ++ ) {
							try {
								asignatura.EliminarAlumAsig(idsAsig.get(i));
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							idsAsig.remove(i);
						}
					}
					
					try {
						asignatura.Modificar(idsAsig);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				banderaGuardar = false;
				btnGuardar.setEnabled(false);
				textFieldCodigo.setText("");
				textFieldNombre.setText("");
				boxCurso.setSelectedIndex(0);
				boxMateria.setSelectedIndex(0);
				boxAlumnos.setSelectedIndex(0);
				boxProfesor.setSelectedIndex(0);
				list.removeAllElements();
				listaDeAlumnos.removeAll();
			}
		}
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			AsignaturaWindow ventana = new AsignaturaWindow(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	//FUNCION PARA CARGAR UN ALUMNO AL SCROLL
	private class CargaAlum extends AbstractAction {
		public CargaAlum() {
			putValue(NAME, "Cargar Alumno");
		}
		public void actionPerformed(ActionEvent e) {
			try {
				CargarScroll();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	
}
