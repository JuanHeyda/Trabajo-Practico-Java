package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import Proyecto.MateriaDAO;
import ar.com.gugler.sgc.modelo.Materia;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

import javax.swing.Action;

@SuppressWarnings("serial")
public class MateriaWindow extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private String user;
	private JTextField textFieldAnio;
	private final Action actionVolver = new FuncionVolver();
	private final Action actionGuardar = new FuncionGuardar();
	private JList<Integer> listaMaterias;
	private final Action actionModificar = new FuncionModificar();
	private final Action actionEliminar = new FuncionEliminar();
	private boolean bandera = false;
	private Long idModificar;

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MateriaWindow frame = new MateriaWindow(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MateriaWindow(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblAnio = new JLabel("A\u00F1o: ");
		lblAnio.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblAnio.setBounds(277, 223, 46, 14);
		contentPane.add(lblAnio);
		
		JLabel lblNewLabel = new JLabel("Materia Almacenadas");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 149, 195, 22);
		contentPane.add(lblNewLabel);
		
		JLabel lblTitulo = new JLabel("Gestionar Materias");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//TEXTFIELD
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		textFieldAnio = new JTextField();
		textFieldAnio.setFont(new Font("Rockwell", Font.BOLD, 11));
		textFieldAnio.setBounds(333, 220, 86, 20);
		contentPane.add(textFieldAnio);
		textFieldAnio.setColumns(10);
		ValidacionNumeros(textFieldAnio);
		
		//LIST
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 177, 86, 118);
		contentPane.add(scrollPane);
		
		listaMaterias = new JList<Integer>();
		listaMaterias.setFont(new Font("Rockwell", Font.BOLD, 11));
		scrollPane.setViewportView(listaMaterias);
		
		//BOTTONS
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(20, 320, 89, 23);
		contentPane.add(btnVolver);
		
		JButton btnModificar = new JButton("");
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setAction(actionModificar);
		btnModificar.setBounds(116, 182, 89, 23);
		contentPane.add(btnModificar);
		
		JButton btnEliminar = new JButton("");
		btnEliminar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnEliminar.setAction(actionEliminar);
		btnEliminar.setBounds(116, 267, 89, 23);
		contentPane.add(btnEliminar);

		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnGuardar.setAction(actionGuardar);
		btnGuardar.setBounds(312, 248, 89, 23);
		contentPane.add(btnGuardar);
		
		MostrarFechasGuardadas();
	}
	
	//VALIDA QUE SOLO SE ESCRIBAN NUMEROS 
	public void ValidacionNumeros(JTextField a) {
        a.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e ) {

                char c = e.getKeyChar();

                if((!Character.isDigit(c))) {
                    e.consume();
                }
            }
        });
    }
	
	//MUESTRA TODAS LAS FECHAS GUARDADAS DE LA MATERIA
	public void MostrarFechasGuardadas() {
		
		Materia mate = new Materia();
		
		listaMaterias.setModel( mate.FechasGuardadas());
		
	}
	
	//EXTRAIGO UN ANIO, Y EL ID DEL MISMO PARA PODER MODIFICARLO
	public void ModificarCurso() throws SQLException{
			
		Materia curso = new Materia();
		MateriaDAO dao = new MateriaDAO();
			
		curso = dao.MateriaModificar(listaMaterias.getSelectedValue());
			
		String aux = "" + curso.getAnio();
		idModificar=curso.getId();
		textFieldAnio.setText(aux);
			
	}
	
	//FUNCION PARA GUARDAR UN ANIO EN LA MATERIA. NO SE ACEPTAN REPETICIONES DE ANIOS
	private class FuncionGuardar extends AbstractAction {
		public FuncionGuardar() {
			putValue(NAME, "Guardar");
		}
		public void actionPerformed(ActionEvent e) {

			Materia mate = new Materia(); 
			
			if(textFieldAnio.getText().equals("")) {
				JOptionPane.showMessageDialog(null , "Anio vacio", "ERROR", JOptionPane.INFORMATION_MESSAGE );
			}else {
				boolean validar = mate.ValidarFecha(textFieldAnio.getText());
				
				
				if(validar) {
					if(bandera == false) {
						int anio = Integer.parseInt(textFieldAnio.getText());
						mate.setAnio(anio);
							
						try {
							mate.ValidarDuplicados(bandera, mate);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
							
						}
					}else {
						
						int anio = Integer.parseInt(textFieldAnio.getText());
						mate.setAnio(anio);
						mate.setId(idModificar);
						
						try {
							mate.ValidarDuplicados(bandera, mate);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}else {
					JOptionPane.showMessageDialog(null , "Escribir solamente un a�o / cuatro digitos", "ERROR", JOptionPane.INFORMATION_MESSAGE );
				}
			}
			
			textFieldAnio.setText("");
			bandera = false;
			MostrarFechasGuardadas();
		}
	}
	
	
	
	//FUNCION PARA MODIFICAR SEGUN UN ANIO, VALIDO QUE NO EXISTA YA
	private class FuncionModificar extends AbstractAction {
		public FuncionModificar() {
			putValue(NAME, "Modificar");
		}
		public void actionPerformed(ActionEvent e) {
			bandera = true;
			
			if(listaMaterias.getSelectedValue() == null) {
				
				JOptionPane.showMessageDialog(null , "Seleccione una materia para modificar!", "Error", JOptionPane.INFORMATION_MESSAGE );
				
			}else {
				try {
					ModificarCurso();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	
	//FUNCION PARA ELIMINAR UNA MATERIA, CON SUS RESPECTIVAS VALIDACIONES.
	private class FuncionEliminar extends AbstractAction {
		public FuncionEliminar() {
			putValue(NAME, "Eliminar");
		}
		public void actionPerformed(ActionEvent e) {
			
			if(listaMaterias.getSelectedValue() == null) {
				
				JOptionPane.showMessageDialog(null , "Seleccione una materia para modificar!", "Error", JOptionPane.INFORMATION_MESSAGE );
				
			}else {
				
				Materia materia = new Materia();
				try {
					materia.EliminarMateria(listaMaterias.getSelectedValue());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
				
				JOptionPane.showMessageDialog(null , "El anio: "+ listaMaterias.getSelectedValue() +" eliminado!", "Error", JOptionPane.INFORMATION_MESSAGE );
				
				MostrarFechasGuardadas();
			}
			
			
		}
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAsignatura ventana = new GestionarAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
