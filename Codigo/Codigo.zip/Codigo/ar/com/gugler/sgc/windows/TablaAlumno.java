package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Proyecto.AlumnoDAO;
import ar.com.gugler.sgc.modelo.Alumno;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class TablaAlumno extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private JTable tableAlumno;
	private JScrollPane scrollPane;
	private String user;
	private final Action actionVolver = new FuncionVolver();

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TablaAlumno frame = new TablaAlumno(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TablaAlumno(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Tabla de Alumnos");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(546, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		user=usuario;
		 
		//LIST
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 138, 673, 176);
		contentPane.add(scrollPane);
		
		//TABLAS
		tableAlumno = new JTable();
		tableAlumno.setFont(new Font("Rockwell", Font.PLAIN, 11));
		scrollPane.setViewportView(tableAlumno);
		tableAlumno.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre", "Apellido", "DNI", "Fecha de Nacimiento", "Domicilio ", "Telefono", "E-mail", "Legajo"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableAlumno.getColumnModel().getColumn(0).setResizable(false);
		tableAlumno.getColumnModel().getColumn(1).setResizable(false);
		tableAlumno.getColumnModel().getColumn(2).setResizable(false);
		tableAlumno.getColumnModel().getColumn(3).setResizable(false);
		tableAlumno.getColumnModel().getColumn(4).setResizable(false);
		tableAlumno.getColumnModel().getColumn(5).setResizable(false);
		tableAlumno.getColumnModel().getColumn(6).setResizable(false);
		tableAlumno.getColumnModel().getColumn(7).setResizable(false);
		
		//BOTTONS
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 325, 89, 23);
		contentPane.add(btnVolver);
		
		try {
			CargarDatosTabla();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//MUESTRA TODOS LOS DATOS DE LOS ALUMNOS EN LA TABLA.
	private void CargarDatosTabla() throws SQLException {
		int numCols = tableAlumno.getModel().getColumnCount();
		AlumnoDAO alumDao = new AlumnoDAO();
		
		List<Alumno>alumnos = alumDao.getAll();
		
		for(Alumno a: alumnos) {
			Object [] fila = new Object[numCols];
			
			fila[0] = a.getNombres();
			fila[1] = a.getApellido();
			fila[2] = a.getNumeroDocumento();
			fila[3] = a.getFechaNacimiento();
			fila[4] = a.getDomicilio();
			fila[5] = a.getTelefono();
			fila[6] = a.getCorreoElectronico();
			fila[7] = a.getLegajo();

			((DefaultTableModel) tableAlumno.getModel()).addRow(fila);
			
			numCols++;
		}
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAlumnos ventana = new GestionarAlumnos(user);	
			ventana.setVisible(true);
			dispose();	
		}
	}
}
