package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

@SuppressWarnings("serial")
public class GestionarAsignatura extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private String user;
	private final Action actionMateria = new GestionMateria();
	private final Action actionCurso = new GestionCurso();
	private final Action actionAsignatura = new GestionAsignatura();
	private final Action actionVolver = new FuncionVolver();
	
	/**
	 * Launch the application.
	 */
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionarAsignatura frame = new GestionarAsignatura(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionarAsignatura(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//JLABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		//TEXTFIELD
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		//JBOTTONS
		JButton btnMateria = new JButton("Materia");
		btnMateria.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnMateria.setAction(actionMateria);
		btnMateria.setBounds(235, 122, 142, 30);
		contentPane.add(btnMateria);
		
		JButton btnCurso = new JButton("Curso");
		btnCurso.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnCurso.setAction(actionCurso);
		btnCurso.setBounds(235, 163, 142, 30);
		contentPane.add(btnCurso);
		
		JButton btnAsignatura = new JButton("Asignatura");
		btnAsignatura.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAsignatura.setAction(actionAsignatura);
		btnAsignatura.setBounds(235, 204, 142, 30);
		contentPane.add(btnAsignatura);

		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(25, 317, 89, 23);
		contentPane.add(btnVolver);
		
	}
	private class GestionMateria extends AbstractAction {
		public GestionMateria() {
			putValue(NAME, "Materia");
		}
		public void actionPerformed(ActionEvent e) {
			MateriaWindow ventana = new MateriaWindow(user);
			ventana.setVisible(true);
			dispose();	
		}
	}
	private class GestionCurso extends AbstractAction {
		public GestionCurso() {
			putValue(NAME, "Curso");
		}
		public void actionPerformed(ActionEvent e) {
			CursoWindows ventana = new CursoWindows(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	private class GestionAsignatura extends AbstractAction {
		public GestionAsignatura() {
			putValue(NAME, "Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			AsignaturaWindow ventana = new AsignaturaWindow(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			MainWindows ventana = new MainWindows(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
