package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import ar.com.gugler.sgc.modelo.Asignatura;

@SuppressWarnings("serial")
public class EliminarAsignatura extends JFrame {

	private JPanel contentPane;
	private String user;
	private JComboBox<String> boxAsignatura;
	private JTextField textCodAsig;
	private JTextField textField;
	private final Action actionVolver = new Volver();
	private final Action actionModificar = new EliminarAsig();
	private final Action actionBuscar = new BuscarCodAsig();
	private JButton btnVolver;
	private JButton btnModificar;
	private Asignatura asignatura;

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarAsignatura frame = new EliminarAsignatura(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public EliminarAsignatura(String usuario) {
		setBackground(Color.WHITE);
		user= usuario;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		contentPane.setBackground(Color.white);
		
		//LABELS
		JLabel lblProfesor = new JLabel("Asignaturas:");
		lblProfesor.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblProfesor.setBounds(145, 28, 98, 22);
		contentPane.add(lblProfesor);
		
		JLabel lblBuscarDni = new JLabel("Buscar por Codigo:");
		lblBuscarDni.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblBuscarDni.setBounds(145, 104, 123, 14);
		contentPane.add(lblBuscarDni);
		
		//CHECKBOX
		boxAsignatura = new JComboBox<String>();
		boxAsignatura.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxAsignatura.setBounds(151, 61, 134, 22);
		contentPane.add(boxAsignatura);
		
		//TEXTLABELS
		textCodAsig = new JTextField();
		textCodAsig.setFont(new Font("Rockwell", Font.BOLD, 11));
		textCodAsig.setBounds(153, 129, 132, 20);
		contentPane.add(textCodAsig);
		textCodAsig.setColumns(10);
		ValidacionNumeros(textCodAsig);
		
		textField = new JTextField();
		textField.setText("Usuario: <dynamic>");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Rockwell", Font.BOLD, 13));
		textField.setEditable(false);
		textField.setColumns(10);
		textField.setBorder(null);
		textField.setBackground(Color.WHITE);
		textField.setBounds(287, 11, 137, 20);
		contentPane.add(textField);
		contentPane.add(textField);
		
		//AGREGO USUARIO EN LA ESQUINA DE LA VENTANA.
		String firstLtr = usuario.substring(0, 1);
	    String restLtrs = usuario.substring(1, usuario.length());
	    firstLtr = firstLtr.toUpperCase();
	    usuario = firstLtr + restLtrs;
		textField.setText("Usuario: " + usuario);
		
		//BOTONS
		JButton btnBuscar = new JButton("New button");
		btnBuscar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnBuscar.setAction(actionBuscar);
		btnBuscar.setBounds(175, 160, 89, 23);
		contentPane.add(btnBuscar);
		
		btnVolver = new JButton("");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 214, 89, 23);
		contentPane.add(btnVolver);
		
		btnModificar = new JButton("");
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setAction(actionModificar);
		btnModificar.setBounds(335, 214, 89, 23);
		contentPane.add(btnModificar);
		
		try {
			MostrarAsignatura();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//MOSTRAR LAS ASIGNATURAS EN EL CHECK BOX 
	private void MostrarAsignatura() throws SQLException {
		Asignatura asig = new Asignatura();
		List<String> codNom = new ArrayList<String>();
		
		codNom = asig.ExtraerCodNombre();
		
		//ELIMINO DUPLICADOS DE LA LISTA
		codNom = codNom.stream().distinct().collect(Collectors.toList());
		
		boxAsignatura.addItem("");
		for(int i = 0 ; i < codNom.size() ; i ++){
			boxAsignatura.addItem(codNom.get(i));
		}
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
		public void keyTyped(KeyEvent e ) {
	    	char c = e.getKeyChar();

	        if((!Character.isDigit(c))) {
	        	e.consume();
	        }
	     }
	    });
	}
	
	//SEPARO LOS DATOS DE ASIGNATURA, PARA QUEDARME SOLO CON EL CODIGO DE ASIGNATURA
	public int SepararDatosAsignatura(String asig) {
		String[] a = asig.split(" ");
		
		return Integer.parseInt(a[0]);
		
	}
	
	//BUSCADOR, ESCRIBIR UN CODIGO DE ASIGNATURA Y LO BUSCA EN LA BASE DE DATOS
	private class BuscarCodAsig extends AbstractAction {
		public BuscarCodAsig() {
			putValue(NAME, "Buscar");
		}
		public void actionPerformed(ActionEvent e) {
			
			if(!textCodAsig.getText().isEmpty()) {
				int codAsig = Integer.parseInt(textCodAsig.getText());
				
				for(int i = 1; i < boxAsignatura.getItemCount() ; i++) {
					if(codAsig == SepararDatosAsignatura(boxAsignatura.getItemAt(i))) {
						boxAsignatura.setSelectedIndex(i);
						return;
					}
				}
				JOptionPane.showMessageDialog(null , "Asignatura no encontrado!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}else {
				JOptionPane.showMessageDialog(null , "No seleccionaste ningun Codigo!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
			
		}
	}
	
	//FUNCION PARA ELIMINAR UNA ASIGNATURA
	private class EliminarAsig extends AbstractAction {
		public EliminarAsig() {
			putValue(NAME, "Eliminar");
		}
		public void actionPerformed(ActionEvent e) {
			if(!boxAsignatura.getSelectedItem().equals("")) {
				asignatura = new Asignatura();
				int codAsig = SepararDatosAsignatura((String) boxAsignatura.getSelectedItem());
				
				try {
					asignatura.EliminarAsignatura(codAsig);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}else {
				JOptionPane.showMessageDialog(null , "Seleccionar una asignatura!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
	
	private class Volver extends AbstractAction {
		public Volver() {
			putValue(NAME, "Vovler");
		}
		public void actionPerformed(ActionEvent e) {
			AsignaturaWindow ventana = new AsignaturaWindow(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
