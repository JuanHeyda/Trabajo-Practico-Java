package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;

@SuppressWarnings("serial")
public class GestionarProfesores extends JFrame {

	private JTextField textUsuario;
	private String user;
	private JPanel contentPane;
	private final Action actionAgregarProfesor = new AgrProfesor();
	private final Action actionVolver = new FuncionVolver();
	private final Action actionTablaProfesores = new TProfesores();
	private final Action actionModificar = new ModificarProf();
	private final Action actionEliminar = new ElimProfesor();

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionarProfesores frame = new GestionarProfesores(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GestionarProfesores(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Gestionar Profesor");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);

		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: "+usuario);
		
		//BOTONS
		JButton btnAgregarProfesor = new JButton("");
		btnAgregarProfesor.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAgregarProfesor.setAction(actionAgregarProfesor);
		btnAgregarProfesor.setBounds(235, 122, 150, 30);
		contentPane.add(btnAgregarProfesor);
		
		JButton btnTablaProfesores = new JButton("");
		btnTablaProfesores.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnTablaProfesores.setAction(actionTablaProfesores);
		btnTablaProfesores.setBounds(235, 163, 150, 30);
		contentPane.add(btnTablaProfesores);
		
		JButton btnVolver = new JButton("");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 326, 89, 23);
		contentPane.add(btnVolver);
		
		JButton btnModificar = new JButton("");
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setAction(actionModificar);
		btnModificar.setBounds(235, 204, 150, 30);
		contentPane.add(btnModificar);
		
		JButton btnEliminar = new JButton("");
		btnEliminar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnEliminar.setAction(actionEliminar);
		btnEliminar.setBounds(235, 245, 150, 30);
		contentPane.add(btnEliminar);
	}
	
	
	private class AgrProfesor extends AbstractAction {
		public AgrProfesor() {
			putValue(NAME, "Agregar Profesores");
		}
		public void actionPerformed(ActionEvent e) {
			AgregarProfesor ventana = new AgregarProfesor(user);
			ventana.setVisible(true);		
			dispose();
		}
	}
	
	private class TProfesores extends AbstractAction {
		public TProfesores() {
			putValue(NAME, "Tabla de Profesores");
		}
		public void actionPerformed(ActionEvent e) {
			TablaProfesores ventana = new TablaProfesores(user);
			ventana.setVisible(true);
			dispose();
			
		}
	}
	private class ModificarProf extends AbstractAction {
		public ModificarProf() {
			putValue(NAME, "Modificar Profesores");
		}
		public void actionPerformed(ActionEvent e) {
			ModificarProfesor ventana = new ModificarProfesor(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class ElimProfesor extends AbstractAction {
		public ElimProfesor() {
			putValue(NAME, "Eliminar Profesores");
		}
		public void actionPerformed(ActionEvent e) {
			
			EliminarProfesor ventana = new EliminarProfesor(user);
			ventana.setVisible(true);
			dispose();
			
		}
	}
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			MainWindows ventana = new MainWindows(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
