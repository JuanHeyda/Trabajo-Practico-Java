package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;

@SuppressWarnings("serial")
public class GestionarAlumnos extends JFrame {
	
	private JTextField textUsuario;
	private JPanel contentPane;
	private final Action actionAgregarAlumno = new AgregarAlu();
	private String user;
	private final Action actionTablaAlumno = new TablaAlu();
	private final Action actionVolver = new FuncionVolver();
	private final Action actionModificar = new ModificarAlu();
	private final Action actionEliminar = new EliminarAlu();

	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionarAlumnos frame = new GestionarAlumnos(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GestionarAlumnos(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//JLABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Gestionar Alumnos");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user = usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		//BOTTONS
		JButton btnAgregarAlumno = new JButton("Agregar Alumno");
		btnAgregarAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAgregarAlumno.setAction(actionAgregarAlumno);
		btnAgregarAlumno.setBounds(235, 122, 150, 30);
		contentPane.add(btnAgregarAlumno);
		
		JButton btnTablaDeAlumno = new JButton("Tabla Alumno");
		btnTablaDeAlumno.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnTablaDeAlumno.setAction(actionTablaAlumno);
		btnTablaDeAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnTablaDeAlumno.setBounds(235, 163, 150, 30);
		contentPane.add(btnTablaDeAlumno);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setAction(actionVolver);
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setBounds(10, 325, 89, 23);
		contentPane.add(btnVolver);
		
		JButton btnModificar = new JButton("Modificar Alumno");
		btnModificar.setAction(actionModificar);
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setBounds(235, 204, 150, 30);
		contentPane.add(btnModificar);
		
		JButton btnEliminar = new JButton("Eliminar Alumno");
		btnEliminar.setAction(actionEliminar);
		btnEliminar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnEliminar.setBounds(235, 245, 150, 30);
		contentPane.add(btnEliminar);
		
		
	}
	private class AgregarAlu extends AbstractAction {
		public AgregarAlu() {
			putValue(NAME, "Agregar Alumnos");
		}
		public void actionPerformed(ActionEvent e) {
			AgregarAlumnos ventana = new AgregarAlumnos(user);
			ventana.setVisible(true);
			dispose();
			
		}
	}
	
	private class TablaAlu extends AbstractAction {
		public TablaAlu() {
			putValue(NAME, "Tabla de Alumnos");
		}
		public void actionPerformed(ActionEvent e) {
			TablaAlumno ventana = new TablaAlumno(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class ModificarAlu extends AbstractAction {
		public ModificarAlu() {
			putValue(NAME, "Modificar Alumnos");
		}
		public void actionPerformed(ActionEvent e) {
			ModificarAlumno ventana = new ModificarAlumno(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class EliminarAlu extends AbstractAction {
		public EliminarAlu() {
			putValue(NAME, "Eliminar Alumnos");
		}
		public void actionPerformed(ActionEvent e) {

			EliminarAlumno ventana = new EliminarAlumno(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			MainWindows ventana = new MainWindows(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
