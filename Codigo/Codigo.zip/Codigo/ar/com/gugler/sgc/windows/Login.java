package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ar.com.gugler.sgc.modelo.Usuario;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.Font;

@SuppressWarnings("serial")
public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldUsuario;
	private JPasswordField passwordField;
	private final Action actionAceptar = new ValidarUsuario();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					
					//GENERAR USUARIO
					Usuario user = new Usuario();
					user.GenerarUsuario();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/ar/com/gugler/sgc/imagenes/imagenblanca.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 395, 311);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Login.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(106, 2, 151, 126);
		contentPane.add(lblLogo);
		
		JLabel lblUsuario = new JLabel("Usuario: ");
		lblUsuario.setFont(new Font("Rockwell", Font.BOLD, 11));
		lblUsuario.setBounds(109, 156, 74, 14);
		contentPane.add(lblUsuario);
		
		JLabel lblContrasenia = new JLabel("Contrase\u00F1a: ");
		lblContrasenia.setFont(new Font("Rockwell", Font.BOLD, 11));
		lblContrasenia.setBounds(97, 187, 86, 14);
		contentPane.add(lblContrasenia);
		
		//TEXTFIELDS
		textFieldUsuario = new JTextField();
		textFieldUsuario.setFont(new Font("Rockwell", Font.BOLD, 11));
		textFieldUsuario.setBounds(171, 153, 86, 20);
		contentPane.add(textFieldUsuario);
		textFieldUsuario.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Rockwell", Font.BOLD, 11));
		passwordField.setBounds(171, 184, 86, 20);
		contentPane.add(passwordField);
		
		//BOTTONS
		JButton btnNewButtonAceptar = new JButton("Aceptar");
		btnNewButtonAceptar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnNewButtonAceptar.setAction(actionAceptar);
		btnNewButtonAceptar.setBounds(144, 230, 89, 23);
		contentPane.add(btnNewButtonAceptar);
	
		//CHECKBOX
		JCheckBox chckbxShowPass = new JCheckBox("Mostrar Clave");
		chckbxShowPass.setFont(new Font("Rockwell", Font.BOLD, 11));
		chckbxShowPass.setForeground(Color.BLACK);
		chckbxShowPass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(chckbxShowPass.isSelected()) {
					passwordField.setEchoChar((char)0);
				}
				else {
					passwordField.setEchoChar('*');
					
				}
			}
		});
		chckbxShowPass.setBounds(263, 183, 115, 23);
		chckbxShowPass.setBackground(Color.WHITE);
		contentPane.add(chckbxShowPass);
		
	}
	
	//FUNCION PARA VALIDAR EL USUARIO EN LA BASE DE DATOS
	private class ValidarUsuario extends AbstractAction {
		public ValidarUsuario() {
			putValue(NAME, "Aceptar");
		}
		public void actionPerformed(ActionEvent e) {
			try {
				
				String us = textFieldUsuario.getText().replaceAll("\\s","");
				
				
				Usuario user = new Usuario(us, String.valueOf(passwordField.getPassword()));
				
				if(user.getUsuario().isEmpty()) {
					JOptionPane.showMessageDialog(null , "Ingrese Usuario", "ERROR", JOptionPane.INFORMATION_MESSAGE );
				}else if(user.getContrasenia().isEmpty()) {
					JOptionPane.showMessageDialog(null , "Ingrese Contrase�a", "ERROR", JOptionPane.INFORMATION_MESSAGE );
				}else {
					if(	user.Validacion()) {
						MainWindows ventana = new MainWindows(user.getUsuario());	
						ventana.setVisible(true);
						dispose();	
					}
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
}

