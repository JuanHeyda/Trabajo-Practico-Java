package ar.com.gugler.sgc.windows;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import com.toedter.calendar.JDateChooser;

import ar.com.gugler.sgc.modelo.Profesores;

@SuppressWarnings("serial")
public class AgregarProfesor extends JFrame {

	private JTextField textFieldNumeroDocumento;
	private JTextField textFieldNombre;
	private JTextField textFieldApellido;
	private JTextField textFieldDomicilio;
	private JTextField textFieldTelefono;
	private JTextField textFieldCorreo;
	private JTextField textUsuario;
	private JDateChooser dateFechaNac;
	private JDateChooser dateFechaIngr;
	private JPanel contentPane;
	private String user;
	private final Action actionVolver = new FuncionVolver();
	private final Action actionAgrProfesor = new AgrProfesor();
	private JTextField textFieldCuil;
	private boolean banderaGuardar = false;
	private JButton btnAceptar;
	private Profesores profesorModificar;
	private boolean modificar = false;
	
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarProfesor frame = new AgregarProfesor(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public AgregarProfesor(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//Logo
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Agregar Profesor");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//Label de usuario con su dise�o.
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: "+usuario);
		
		/**
		 * 			FORMULARIO
		 */
		//Nombre
		textFieldNombre = new JTextField();
		textFieldNombre.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldNombre.setBounds(319, 62, 86, 20);
		contentPane.add(textFieldNombre);
		textFieldNombre.setColumns(10);
		textFieldNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		ValidacionLetras(textFieldNombre);
		
		JLabel lblNombre = new JLabel("Nombre/s:");
		lblNombre.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNombre.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNombre.setBounds(170, 64, 127, 14);
		contentPane.add(lblNombre);
		
		
		//Apellido
		textFieldApellido = new JTextField();
		textFieldApellido.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldApellido.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		textFieldApellido.setBounds(319, 93, 86, 20);
		contentPane.add(textFieldApellido);
		textFieldApellido.setColumns(10);
		ValidacionLetras(textFieldApellido);
		
		JLabel lblApellido = new JLabel("Apellido/s:");
		lblApellido.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblApellido.setHorizontalAlignment(SwingConstants.RIGHT);
		lblApellido.setBounds(183, 95, 114, 14);
		contentPane.add(lblApellido);
		
		//Numero de Documento
		textFieldNumeroDocumento = new JTextField();
		textFieldNumeroDocumento.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldNumeroDocumento.setBounds(319, 124, 86, 20);
		contentPane.add(textFieldNumeroDocumento);
		textFieldNumeroDocumento.setColumns(10);
		textFieldNumeroDocumento.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		ValidacionNumeros(textFieldNumeroDocumento);
		
		JLabel lblNumeroDocumento = new JLabel("Numero de Documento:");
		lblNumeroDocumento.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNumeroDocumento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNumeroDocumento.setBounds(121, 126, 176, 14);
		contentPane.add(lblNumeroDocumento);
		
		JLabel lblFechaNacimiento = new JLabel("Fecha de Nacimiento:");
		lblFechaNacimiento.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblFechaNacimiento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFechaNacimiento.setBounds(151, 158, 146, 14);
		contentPane.add(lblFechaNacimiento);
		
		//Domicilio
		textFieldDomicilio = new JTextField();
		textFieldDomicilio.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldDomicilio.setBounds(319, 186, 86, 20);
		contentPane.add(textFieldDomicilio);
		textFieldDomicilio.setColumns(10);
		textFieldDomicilio.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		JLabel lblDomicilio = new JLabel("Domicilio:");
		lblDomicilio.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblDomicilio.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDomicilio.setBounds(170, 188, 127, 14);
		contentPane.add(lblDomicilio);
		
		//Domicilio
		textFieldTelefono = new JTextField();
		textFieldTelefono.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldTelefono.setBounds(319, 217, 86, 20);
		contentPane.add(textFieldTelefono);
		textFieldTelefono.setColumns(10);
		ValidacionNumeros(textFieldTelefono);
		textFieldTelefono.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		JLabel lblTelefono = new JLabel("Telefono:");
		lblTelefono.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblTelefono.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTelefono.setBounds(170, 216, 127, 14);
		contentPane.add(lblTelefono);
		
		//Correo
		textFieldCorreo = new JTextField();
		textFieldCorreo.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldCorreo.setBounds(319, 246, 86, 20);
		contentPane.add(textFieldCorreo);
		textFieldCorreo.setColumns(10);
		textFieldCorreo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		JLabel lblCorreo = new JLabel("Correo Electronico:");
		lblCorreo.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblCorreo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCorreo.setBounds(170, 248, 127, 14);
		contentPane.add(lblCorreo);
		
		dateFechaNac = new JDateChooser();
		dateFechaNac.getCalendarButton().setFont(new Font("Rockwell", Font.BOLD, 11));
		dateFechaNac.setBounds(319, 155, 107, 20);
		contentPane.add(dateFechaNac);
		
		JLabel lblCuil = new JLabel("CUIL:");
		lblCuil.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCuil.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblCuil.setBounds(251, 279, 46, 14);
		contentPane.add(lblCuil);
		
		textFieldCuil = new JTextField();
		textFieldCuil.setFont(new Font("Dialog", Font.BOLD, 11));
		textFieldCuil.setBounds(319, 277, 86, 20);
		contentPane.add(textFieldCuil);
		textFieldCuil.setColumns(10);
		textFieldCuil.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				ComprobarBotonGuardar();
			}
		});
		
		ValidacionNumeros(textFieldCuil);
		
		JLabel lblFechaIngreso = new JLabel("Fecha de Ingreso:");
		lblFechaIngreso.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFechaIngreso.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblFechaIngreso.setBounds(176, 312, 121, 14);
		contentPane.add(lblFechaIngreso);
		
		dateFechaIngr = new JDateChooser();
		dateFechaIngr.getCalendarButton().setFont(new Font("Rockwell", Font.BOLD, 11));
		dateFechaIngr.setBounds(319, 308, 107, 20);
		contentPane.add(dateFechaIngr);
		
		/*
		 *			BOTONES 
		 */
		JButton btnVolver = new JButton("");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 312, 89, 23);
		contentPane.add(btnVolver);
		
		btnAceptar = new JButton("");
		btnAceptar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAceptar.setAction(actionAgrProfesor);
		btnAceptar.setBounds(10, 188, 89, 23);
		contentPane.add(btnAceptar);
		btnAceptar.setEnabled(false);
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD (CUPOS)
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
	    public void keyTyped(KeyEvent e ) {
	    	char c = e.getKeyChar();
	        if((!Character.isDigit(c))) {
	        	e.consume();
	        }
	    }
	    });
	}
	
	//VALIDO QUE SEAN SOLAMENTE LETRAS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionLetras(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e ) {
				char c = e.getKeyChar();

				if((!Character.isAlphabetic(c))) {
					e.consume();
			    }
			}
		});
	}
	
	//COMPRUEBA QUE TODOS LOS DATOS ESTEN CARGADOS ASI SE ACTIVA EL BOTON GUARDAR
	private void ComprobarBotonGuardar() {
		if(	!textFieldNombre.getText().isEmpty() && !textFieldApellido.getText().isEmpty() 
			&& !textFieldNumeroDocumento.getText().isEmpty() && !textFieldCuil.getText().isEmpty()
			&& !textFieldDomicilio.getText().isEmpty() && textFieldCorreo.getText().indexOf('@')!=-1
			&& !textFieldCorreo.getText().isEmpty() && !textFieldTelefono.getText().isEmpty() 
			&& banderaGuardar == false){
					
			btnAceptar.setEnabled(true);
			banderaGuardar = true;
		}
	}
	
	//FUNCION PARA GUARDAR, DEPENDIENDO DE LA BANDERA DE modificar ES PARA GUARDAR O PARA MODIFICAR
	private class AgrProfesor extends AbstractAction {
		public AgrProfesor() {
			putValue(NAME, "Aceptar");
		}
		public void actionPerformed(ActionEvent e) {
			Date nac= dateFechaNac.getDate();
			Date ingr = dateFechaIngr.getDate();
				
			if(nac!= null && ingr != null) {
				Profesores profe = new Profesores();
				
				profe.setNombres(textFieldNombre.getText());
				profe.setApellido(textFieldApellido.getText());
				profe.setNumeroDocumento(Long.parseLong(textFieldNumeroDocumento.getText()));
				profe.setFechaNacimiento(dateFechaNac.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
				profe.setDomicilio(textFieldDomicilio.getText());
				profe.setTelefono(textFieldTelefono.getText());
				profe.setCorreoElectronico(textFieldCorreo.getText());
				profe.setCuil(textFieldCuil.getText());
				profe.setFechaIngreso(dateFechaIngr.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
				
				if(profe.ValidarProfesor(Long.parseLong(textFieldNumeroDocumento.getText())) && modificar == false ) {
					try {
						profe.AlmacenarProfesor(profe);
						
						textFieldNombre.setText("");
						textFieldApellido.setText("");
						textFieldNumeroDocumento.setText("");
						textFieldDomicilio.setText("");
						textFieldTelefono.setText("");
						textFieldCorreo.setText("");
						textFieldCuil.setText("");
						dateFechaIngr.setDate(null);
						dateFechaNac.setDate(null);

					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
						
				}else if(modificar == true) {
					try {
						long id = profe.idExtraer(profesorModificar.getNumeroDocumento());
						profe.setId(id);
						profe.Modificar(profe);
						
						modificar=false;
						
						textFieldNombre.setText("");
						textFieldApellido.setText("");
						textFieldNumeroDocumento.setText("");
						textFieldDomicilio.setText("");
						textFieldTelefono.setText("");
						textFieldCorreo.setText("");
						textFieldCuil.setText("");
						dateFechaIngr.setDate(null);
						dateFechaNac.setDate(null);

					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else {
					JOptionPane.showMessageDialog(null , "Profesor ya almacenado!", "ERROR", JOptionPane.INFORMATION_MESSAGE );
				}
			}else {
				JOptionPane.showMessageDialog(null , "Agregue una fecha!", "ERROR", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
	
	//FUNCION PARA ASIGNAR TODOS LOS DATOS DEL PROFESOR A MODIFICAR
	public void ProfesorModificar(Profesores profe) {
		this.profesorModificar = profe;
		modificar = true;

		ZoneId defaultZoneId = ZoneId.systemDefault();
		Date date = Date.from(profesorModificar.getFechaNacimiento().atStartOfDay(defaultZoneId).toInstant());
		Date date1 = Date.from(profesorModificar.getFechaIngreso().atStartOfDay(defaultZoneId).toInstant());
		
		textFieldNombre.setText(profesorModificar.getNombres());
		textFieldApellido.setText(profesorModificar.getApellido());
		textFieldNumeroDocumento.setText(profesorModificar.getNumeroDocumento().toString());
		textFieldDomicilio.setText(profesorModificar.getDomicilio());
		textFieldTelefono.setText(profesorModificar.getTelefono());
		textFieldCorreo.setText(profesorModificar.getCorreoElectronico());
		textFieldCuil.setText(profesorModificar.getCuil());
		dateFechaIngr.setDate(date1);
		dateFechaNac.setDate(date);
	}
	
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarProfesores ventana = new GestionarProfesores(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
}
