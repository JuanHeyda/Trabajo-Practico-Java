package ar.com.gugler.sgc.windows;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


@SuppressWarnings("serial")
public class AsignaturaWindow extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private String user;
	private final Action actionVolver = new FuncionVolver();
	private final Action actionAgregar = new AgregarAsig();
	private final Action actionTabla = new TablaAsig();
	private final Action actionModificar = new ModificarAsig();
	private final Action actionEliminar = new EliminarAsig();
	
	/**
	 * Launch the application.
	 */
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AsignaturaWindow frame = new AsignaturaWindow(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AsignaturaWindow(String usuario) {
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Gestionar Asignatura");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblTitulo.setBounds(161, 23, 176, 23);
		contentPane.add(lblTitulo);
		
		//TEXTFIELDS
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(347, 11, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText("Usuario: " + usuario);
		
		//BOTONS
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(25, 317, 89, 23);
		contentPane.add(btnVolver);
		
		JButton btnAgregar = new JButton("");
		btnAgregar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAgregar.setAction(actionAgregar);
		btnAgregar.setBounds(235, 122, 150, 30);
		contentPane.add(btnAgregar);
		
		JButton btnTabla = new JButton("");
		btnTabla.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnTabla.setAction(actionTabla);
		btnTabla.setBounds(235, 163, 150, 30);
		contentPane.add(btnTabla);
		
		JButton btnModificar = new JButton("");
		btnModificar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificar.setAction(actionModificar);
		btnModificar.setBounds(235, 204, 150, 30);
		contentPane.add(btnModificar);
		
		JButton btnEliminar = new JButton("");
		btnEliminar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnEliminar.setAction(actionEliminar);
		btnEliminar.setBounds(235, 245, 150, 30);
		contentPane.add(btnEliminar);
		
		
	}
	
	private class FuncionVolver extends AbstractAction {
		public FuncionVolver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAsignatura ventana = new GestionarAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class AgregarAsig extends AbstractAction {
		public AgregarAsig() {
			putValue(NAME, "Agregar Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			AgregarAsignatura ventana = new AgregarAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class TablaAsig extends AbstractAction {
		public TablaAsig() {
			putValue(NAME, "Tabla Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			TablaAsignatura ventana = new TablaAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class ModificarAsig extends AbstractAction {
		public ModificarAsig() {
			putValue(NAME, "Modificar Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			ModificarAsignatura ventana = new ModificarAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class EliminarAsig extends AbstractAction {
		public EliminarAsig() {
			putValue(NAME, "Eliminar Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			EliminarAsignatura ventana = new EliminarAsignatura(user);
			ventana.setVisible(true);
			dispose();
		}
	}
}
