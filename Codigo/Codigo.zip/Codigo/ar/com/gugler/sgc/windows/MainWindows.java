package ar.com.gugler.sgc.windows;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Proyecto.AlumnoDAO;
import Proyecto.AsignaturaDAO;
import Proyecto.Connection;
import Proyecto.CursoDAO;
import Proyecto.MateriaDAO;
import Proyecto.ProfesorDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.swing.Action;

@SuppressWarnings("serial")
public class MainWindows extends JFrame {

	private JPanel contentPane;
	private JTextField textUsuario;
	private final Action actionGestionAlumnos = new GestionAlum();
	private final Action actionGestionProfesores = new GestionProfesores();
	private final Action actionGestionarAsignatura = new GestionAsignatura();
	private String user;
	private final Action actionCerrarSesion = new CierreDeSesion();
	private final Action actionBackup = new GenerarBackup();
	
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindows frame = new MainWindows(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public MainWindows(String usuario) { 
		
		setResizable(false);
		setTitle("TP FINAL");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		//LABELS
		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setIcon(new ImageIcon(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/logo.png")));
		lblLogo.setBounds(0, 0, 151, 133);
		contentPane.add(lblLogo);
		
		JLabel lblTitulo = new JLabel("Sistema de Gestion de Gugler\r\n");
		lblTitulo.setFont(new Font("Rockwell", Font.BOLD, 20));
		lblTitulo.setBounds(166, 26, 318, 40);
		contentPane.add(lblTitulo);
		
		JLabel lblBienvenido = new JLabel("Bienvenido");
		lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
		lblBienvenido.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblBienvenido.setBounds(0, 137, 127, 14);
		contentPane.add(lblBienvenido);
		
		//BOTTONS
		JButton btnAgregarAlumno = new JButton("Agregar Alumno");
		btnAgregarAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAgregarAlumno.setAction(actionGestionAlumnos);
		btnAgregarAlumno.setBounds(209, 137, 151, 30);
		contentPane.add(btnAgregarAlumno);
		
		JButton btnAgregarProfesor = new JButton("Agregar Profesor");
		btnAgregarProfesor.setAction(actionGestionProfesores);
		btnAgregarProfesor.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAgregarProfesor.setBounds(209, 188, 151, 30);
		contentPane.add(btnAgregarProfesor);
		
		JButton btnModificarAlumno = new JButton("Gestionar Asignaturas");
		btnModificarAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnModificarAlumno.setAction(actionGestionarAsignatura);
		btnModificarAlumno.setBounds(209, 239, 151, 30);
		contentPane.add(btnModificarAlumno);
		
		JButton btnCerrarSesion = new JButton("Cerrar Sesion");
		btnCerrarSesion.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnCerrarSesion.setAction(actionCerrarSesion);
		btnCerrarSesion.setBounds(10, 322, 117, 23);
		contentPane.add(btnCerrarSesion);
		
		//TEXTFIELD
		textUsuario = new JTextField();
		textUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		textUsuario.setFont(new Font("Rockwell", Font.BOLD, 13));
		textUsuario.setEditable(false);
		textUsuario.setBounds(-10, 157, 137, 20);
		contentPane.add(textUsuario);
		textUsuario.setColumns(10);
		textUsuario.setBorder(null);
		textUsuario.setBackground(Color.white);
		
		user=usuario;
        String firstLtr = usuario.substring(0, 1);
        String restLtrs = usuario.substring(1, usuario.length());
        firstLtr = firstLtr.toUpperCase();
        usuario = firstLtr + restLtrs;
		textUsuario.setText(usuario);
		
		JButton btnBackup = new JButton("GenerarBackup");
		btnBackup.setAction(actionBackup);
		btnBackup.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnBackup.setBounds(318, 322, 145, 23);
		contentPane.add(btnBackup);
		
		try {
			CrearTablas();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//FUNCION PARA CREAR TODAS LAS TABLAS CUANDO ARRANCA EL PROGRAMA
	private void CrearTablas() throws SQLException {
		AlumnoDAO.createTable();
		CursoDAO.createTable();
		MateriaDAO.createTable();
		ProfesorDAO.createTable();
		AsignaturaDAO.createTable();
	}
	
	private class GestionAlum extends AbstractAction {
		public GestionAlum() {
			putValue(NAME, "Gestionar Alumnos");
			
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAlumnos ventana = new GestionarAlumnos(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class GestionProfesores extends AbstractAction {
		public GestionProfesores() {
			putValue(NAME, "Gestionar Profesores");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarProfesores ventana = new GestionarProfesores(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
	private class GestionAsignatura extends AbstractAction {
		public GestionAsignatura() {
			putValue(NAME, "Gestionar Asignatura");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAsignatura ventana= new GestionarAsignatura(user);
			ventana.setVisible(true);
			dispose();
			
		}
	}
	private class CierreDeSesion extends AbstractAction {
		public CierreDeSesion() {
			putValue(NAME, "Cerrar Sesion");
		}
		public void actionPerformed(ActionEvent e) {
			Login ventana = new Login();
			ventana.setVisible(true);
			dispose();
		}
	}
	private class GenerarBackup extends AbstractAction {
		public GenerarBackup() {
			putValue(NAME, "Generar Backup");
		}
		public void actionPerformed(ActionEvent e) {
			
			Date date = new Date();
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			dateFormat.format(date);
			LocalDate a = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			String aux = "./base/Backup/ "+ a.getDayOfMonth() +"-" + a.getYear() +".zip";
			
			java.sql.Connection connection = Connection.getInstance().getConnection();
			Statement stmt;
			try {
				stmt = connection.createStatement();
				stmt.execute(String.format("BACKUP TO '%s' ", aux));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null , "Backup generado del mes: " + a.getDayOfMonth() + "/"+ a.getYear(), "Felicidades", JOptionPane.INFORMATION_MESSAGE );
		}
	}
}

