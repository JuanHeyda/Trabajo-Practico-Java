package ar.com.gugler.sgc.windows;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ar.com.gugler.sgc.modelo.Alumno;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class EliminarAlumno extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private final Action actionVolver = new Volver();
	private String user;
	private JTextField textFieldAlumno;
	private JComboBox<String> boxAlumno;
	private final Action actionBuscar = new BuscarAlum();
	private final Action actionAceptar = new ModificarAlum();
	
	public static void main(String usuario) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarAlumno frame = new EliminarAlumno(usuario);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public EliminarAlumno(String usuario) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindows.class.getResource("/ar/com/gugler/sgc/imagenes/Iconita.png")));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		user=usuario;
		setLocationRelativeTo(null);
		contentPane.setBackground(Color.white);
		
		//TEXTFIELDS. 
		textFieldAlumno = new JTextField();
		textFieldAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		textFieldAlumno.setColumns(10);
		textFieldAlumno.setBounds(153, 129, 132, 20);
		contentPane.add(textFieldAlumno);
		ValidacionNumeros(textFieldAlumno);
		
		textField = new JTextField();
		textField.setText("Usuario: <dynamic>");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Rockwell", Font.BOLD, 13));
		textField.setEditable(false);
		textField.setColumns(10);
		textField.setBorder(null);
		textField.setBackground(Color.WHITE);
		textField.setBounds(287, 11, 137, 20);
		contentPane.add(textField);
		contentPane.add(textField);
		
		//AGREGO USUARIO EN LA ESQUINA DE LA VENTANA.
		String firstLtr = usuario.substring(0, 1);
	    String restLtrs = usuario.substring(1, usuario.length());
	    firstLtr = firstLtr.toUpperCase();
	    usuario = firstLtr + restLtrs;
		textField.setText("Usuario: " + usuario);
		
		//CHECKBOX ALUMNOS.
	    boxAlumno = new JComboBox<String>();
	    boxAlumno.setFont(new Font("Rockwell", Font.BOLD, 11));
		boxAlumno.setBounds(151, 61, 134, 22);
		contentPane.add(boxAlumno);
		
		//LABELS.
		JLabel lblAlumnos = new JLabel("Alumnos:");
		lblAlumnos.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblAlumnos.setBounds(145, 28, 98, 22);
		contentPane.add(lblAlumnos);
		
		JLabel lblBuscarDni = new JLabel("Buscar por DNI:");
		lblBuscarDni.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblBuscarDni.setBounds(145, 104, 119, 14);
		contentPane.add(lblBuscarDni);
		
		//BOTONES.
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnBuscar.setAction(actionBuscar);
		btnBuscar.setBounds(175, 160, 89, 23);
		contentPane.add(btnBuscar);
		
		JButton btnVolver = new JButton("New button");
		btnVolver.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnVolver.setAction(actionVolver);
		btnVolver.setBounds(10, 214, 89, 23);
		contentPane.add(btnVolver);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Rockwell", Font.BOLD, 11));
		btnAceptar.setAction(actionAceptar);
		btnAceptar.setBounds(335, 214, 89, 23);
		contentPane.add(btnAceptar);
		
		try {
			MostrarAlumnos();
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
	}
	
	//MUESTRA TODOS LOS ALUMNOS EN EL CHECKBOX
	public void MostrarAlumnos() throws SQLException {
		Alumno alum = new Alumno();
		List<Alumno> aux = new ArrayList<>();
		aux = alum.GetNombreBD();
		
		boxAlumno.addItem("");
		for(int i = 0; i < aux.size(); i++) {
			alum = aux.get(i);
			
			String str = alum.getApellido() + " " + alum.getNombres() + " " + alum.getNumeroDocumento();
			
			boxAlumno.addItem(str);
		}
	}
	
	//VALIDO QUE SEAN SOLAMENTE NUMEROS LO QUE SE ESCRIBAN EN EL TEXTFIELD
	public void ValidacionNumeros(JTextField a) {
		a.addKeyListener(new KeyAdapter() {
		public void keyTyped(KeyEvent e ) {
	    	char c = e.getKeyChar();
	        if((!Character.isDigit(c))) {
	        	e.consume();
	        }
	     }
	    });
	}
		
	//EXTRAIGO SOLAMENTE EL DNI
	public Long SepararDatosAlumnos(String alum) {
		String[] a = alum.split(" ");
			
		return Long.parseLong(a[a.length-1]);
	}	
	
	//BOTON PARA BUSCAR UN ALUMNO, EXTRAIGO LO ESCRITO Y BUSCO EN LA BASE DE DATOS SEGUN EL NUMERO DOCUMENTO! 
	private class BuscarAlum extends AbstractAction {
		public BuscarAlum() {
			putValue(NAME, "Buscar");
		}
		public void actionPerformed(ActionEvent e) {
			if(!textFieldAlumno.getText().isEmpty()) {
				
				long dni = Long.parseLong(textFieldAlumno.getText());
				
				for(int i = 0; i < boxAlumno.getItemCount() ; i++) {
					
					if(dni == SepararDatosAlumnos(boxAlumno.getItemAt(i))) {
						boxAlumno.setSelectedIndex(i);
					}
				}
				JOptionPane.showMessageDialog(null , "Alumno no encontrado!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}else {
				JOptionPane.showMessageDialog(null , "No seleccionaste ningun DNI!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
		
	//BOTON PARA ELIMINAR UN ALUMNO, EXTRAE EL DNI DEL ALUMNO Y LO ELIMINA, TAMBIEN SE ELIMINARA LA ASIGNATURA QUE ESTE VINCULADA A ESTE ALUMNO.
	private class ModificarAlum extends AbstractAction {
	public ModificarAlum() {
		putValue(NAME, "Eliminar");
	}
		public void actionPerformed(ActionEvent e){
			if(!boxAlumno.getSelectedItem().equals("")) {
				Long dni = SepararDatosAlumnos((String) boxAlumno.getSelectedItem());
				
				Alumno alum = new Alumno();
				try {
					alum.EliminarAlumno(dni);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null , "Alumno: " + boxAlumno.getSelectedItem() + " eliminado!", "Error", JOptionPane.INFORMATION_MESSAGE );
				boxAlumno.removeAllItems();
				try {
					MostrarAlumnos();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}else {
				JOptionPane.showMessageDialog(null , "Seleccionar un Alumno!", "Error", JOptionPane.INFORMATION_MESSAGE );
			}
		}
	}
	
	//BOTON VOLVER ATRAS
	private class Volver extends AbstractAction {
		public Volver() {
			putValue(NAME, "Volver");
		}
		public void actionPerformed(ActionEvent e) {
			GestionarAlumnos ventana = new GestionarAlumnos(user);
			ventana.setVisible(true);
			dispose();
		}
	}
	
}
