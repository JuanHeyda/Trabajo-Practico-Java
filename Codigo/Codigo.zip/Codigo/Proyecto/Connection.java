package Proyecto;

import java.sql.DriverManager;
import java.sql.SQLException;

//CONEXION A LA BASE DE DATOS. BASE DE DATOS A UTILIZAR H2.
public class Connection {

	private static Connection instance;
	private java.sql.Connection con;
	
	@SuppressWarnings("deprecation")
	private Connection() {
		String url = "jdbc:h2:./base/Tp2";
		try {
			Class.forName("org.h2.Driver").newInstance();
			this.con = DriverManager.getConnection(url,"sa","");
		} catch (SQLException |  InstantiationException | IllegalAccessException
				| ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Error conectandose a la base de datos");
		}
	}

	public static Connection getInstance(){
		if (instance == null) {
			instance = new Connection();
		}
		return instance;
	}
	
	
	public java.sql.Connection getConnection() {
		return this.con;
	}
	
	public void closeConnection() {
		try {
			con.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error cerrando la conexion a la base");
		}
	}
}
