package Proyecto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ar.com.gugler.sgc.modelo.Curso;

/**
 * @author Renzo Carletti & Heyda Juan Pablo
 *
 */
public class CursoDAO extends GenericDAO<Curso> {

	@Override
	public String getTable() {
		return "CURSO";
	}

	@Override
	protected String getInsertSql() {
		return "insert into CURSO (CURSO_CUPO) "
				+ "values (?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Curso object) throws SQLException {
		preparedStatement.setInt(1, object.getCupo());
	}

	@Override
	protected String getUpdateSql() {
		return "update CURSO set CURSO_CUPO = ? "
				+ "where id = ? ";
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Curso object) throws SQLException {
		preparedStatement.setInt(1, object.getCupo());
		preparedStatement.setLong(2, object.getId());
	}
	

	@Override
	protected Curso populate(ResultSet rs) throws SQLException {
		Long id = rs.getLong(1);
		int cupo= rs.getInt(2);
		
		Curso p = new Curso(cupo);
		p.setId(id);
		return p;
	}
	
	public static void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS CURSO ("
				+ "id long(11) NOT NULL AUTO_INCREMENT, "
				+ "CURSO_CUPO int(11) NOT NULL , "
				+ " PRIMARY KEY (id))");
		st.close();
	}
	
	public boolean FuncionExistente(int cupo) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT CURSO_CUPO from CURSO WHERE CURSO_CUPO = "+ cupo;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			Integer name= rs.getInt(1);
		
			if(name!= null) {
				return true;
			}
		} 
		return false;
	}
	
	//FUNCION PARA MODIFICAR UN CURSO SEGUN UN CUPO.
	public Curso CursoModificar(int cupo) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT id from CURSO WHERE CURSO_CUPO = "+ cupo;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next()) {
			Long id = rs.getLong(1);
			Curso p = new Curso(cupo);
			p.setId(id);
			return p;
		}
		return null;
		
	}
	
	//DEVUELVE UN CURSO SEGUN EL ID DE DICHO CURSO
	public Curso ExtraerUnCurso(long id) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT CURSO_CUPO from CURSO WHERE id = "+ id;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next()) {
			Curso p = new Curso(rs.getInt(1));
			p.setId(id);
			return p;
		}
		return null;
		
	}
	
	//ELIMINA EL CURSO POR COMPLETO, AL ESTAR ACTIVO EL ON DELETE CASCADE VA A ELIMINAR TODA REFERENCIA A ESTE CUPO, LO QUE SIGNIFICA QUE PUEDE ELIMINAR UNA ASIGNATURA O VARIAS
	public void EliminarCurso(int cupo) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "DELETE from CURSO where CURSO_CUPO =" + cupo;
		st.execute(query);
	}
}
