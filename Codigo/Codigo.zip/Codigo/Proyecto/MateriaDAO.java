package Proyecto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ar.com.gugler.sgc.modelo.Materia;

public class MateriaDAO extends GenericDAO<Materia> {
	
	
	@Override
	public String getTable() {
		return "MATERIAS";
	}

	@Override
	protected String getInsertSql() {
		return "insert into MATERIAS (MATERIA_ANIO) "
				+ "values (?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Materia object) throws SQLException {
		
		preparedStatement.setInt(1, object.getAnio());
	}

	@Override
	protected String getUpdateSql() {
		return "update MATERIAS set MATERIA_ANIO = ? " + "where ID = ?" ;
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Materia object) throws SQLException {
		preparedStatement.setInt(1, object.getAnio());
		preparedStatement.setLong(2, object.getId());
	}
	

	@Override
	protected Materia populate(ResultSet rs) throws SQLException {
		
		Long id = rs.getLong(1);
		int anio = rs.getInt(2);
		
		Materia p = new Materia(anio);
		p.setId(id);
		return p;
	}
	

	
	public static void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS MATERIAS ( " 
				+ "ID long(11) NOT NULL AUTO_INCREMENT, "
				+ "MATERIA_ANIO int(11) NOT NULL, "
				+ "PRIMARY KEY (ID))");
		st.close();
	}
	
	//SE COMPRUEBA SI EXISTE UNA MATERIA SEGUN EL ANIO COLOCADO
	public boolean FuncionExistente(int mate) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT MATERIA_ANIO from MATERIAS WHERE MATERIA_ANIO = "+ mate;
		
		ResultSet rs = st.executeQuery(query);
		if (rs.next() == true) {
			Integer name= rs.getInt(1);
			
			if(name!= null) {
				return false;
			}
		} 
		return true;
	}
	
	//EXTRAIGO UNA MATERIA SEGUN UN ANIO 
	public Materia MateriaModificar(int anio) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT id from MATERIAS WHERE MATERIA_ANIO = "+ anio;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next()) {
			Long id = rs.getLong(1);
			Materia p = new Materia(anio);
			p.setId(id);
			return p;
		}
		return null;
	}
	
	//EXTRAIGO UNA MATERIA SEGUN UN ID
	public Materia ExtraerUnaMateria(Long id) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT MATERIA_ANIO from MATERIAS WHERE ID = "+ id;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next()) {
			Materia p = new Materia(rs.getInt(1));
			p.setId(id);
			return p;
		}
		return null;
	}
	
	//ELIMINO UNA MATERIA SEGUN UN ANIO, YA QUE NO PUEDE HABER ANIOS REPETIDOS, SE ELIMINARAN TODAS LAS ASIGNATURAS QUE ESTEN VINCULADA CON ESTE ANIO
	public void EliminarMateria(int anio) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "DELETE from MATERIAS where MATERIA_ANIO =" + anio;
		st.execute(query);
		
		
	}
	
}
