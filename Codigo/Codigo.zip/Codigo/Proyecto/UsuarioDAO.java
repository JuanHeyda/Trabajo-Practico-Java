package Proyecto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import ar.com.gugler.sgc.modelo.Usuario;

public class UsuarioDAO extends GenericDAO<Usuario>{

	@Override
	public String getTable() {
		return "USUARIO";
	}

	@Override
	protected String getInsertSql() {
		return "insert into USUARIO (USER,CONTRASENIA)"
				+ "values (?, ?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Usuario object) throws SQLException {
		
		preparedStatement.setString(1, object.getUsuario());
		preparedStatement.setString(2, object.getContrasenia());
	}

	@Override
	protected String getUpdateSql() {
		return "update USUARIO set USER = ?, CONTRASENIA = ?" + "where id = ? ";
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Usuario object) throws SQLException {
		preparedStatement.setString(1, object.getUsuario());
		preparedStatement.setString(2, object.getContrasenia());
		preparedStatement.setLong(3, object.getId());
	}
	

	@Override
	protected Usuario populate(ResultSet rs) throws SQLException {
		Long id = rs.getLong(1);
		String usuario = rs.getString(2);
		String contrasenia = rs.getString(3);
		Usuario p = new Usuario(usuario,contrasenia);
		p.setId(id);
		return p;
	}
	
	public void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS USUARIO ("
				+ "id long(11) NOT NULL AUTO_INCREMENT, "
				+ "USER varchar (15) NOT NULL, "
				+ "CONTRASENIA varchar (15) NOT NULL, "
				+ " PRIMARY KEY (id))");
		st.close();
	}
	
	//SE COMPRUEBA QUE EL USUARIO Y LA CONTRASENIA ESCRITA SEAN CORRECTAS, ESTO SIRVE PARA INGRESAR AL SISTEMA.
	public boolean ValidarUsuario(String usuario, String contrasenia) throws SQLException {

		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT USER, CONTRASENIA from USUARIO WHERE USER =  '"+ usuario+"' AND CONTRASENIA = '"+contrasenia +"'";
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			String name= rs.getString(1);
			String contra = rs.getString(2);
		
			if(name!= null && contra!=null) {
				return true;
			}
		} 
		return false;
		
	}
}
