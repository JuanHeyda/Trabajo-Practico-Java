/**
 * 
 */
package Proyecto;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import ar.com.gugler.sgc.modelo.Profesores;

/**
 * @author
 *
 */
public class ProfesorDAO extends GenericDAO<Profesores> {

	@Override
	public String getTable() {
		return "PROFESOR";
	}

	@Override
	protected String getInsertSql() {
		return "insert into PROFESOR (cuil, numeroDocumento, apellido, nombre, domicilio, telefono, email, fechaNacimiento, fechaIngreso) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Profesores object) throws SQLException {
		
		preparedStatement.setString(1, object.getCuil());
		preparedStatement.setLong(2, object.getNumeroDocumento());
		preparedStatement.setString(3, object.getApellido());
		preparedStatement.setString(4, object.getNombres());
		preparedStatement.setString(5, object.getDomicilio());
		preparedStatement.setString(6, object.getTelefono());
		preparedStatement.setString(7, object.getCorreoElectronico());
		preparedStatement.setDate(8, java.sql.Date.valueOf(object.getFechaNacimiento()));
		preparedStatement.setDate(9, java.sql.Date.valueOf(object.getFechaIngreso()));
	}

	@Override
	protected String getUpdateSql() {
		return "update PROFESOR set cuil = ?, numeroDocumento = ?, apellido = ?, "
				+ "nombre = ?, domicilio = ?, telefono = ?, "
				+ "email = ?, fechaNacimiento = ?, fechaIngreso = ? "
				+ "where id = ? ";
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Profesores object) throws SQLException {
		preparedStatement.setString(1, object.getCuil());
		preparedStatement.setLong(2, object.getNumeroDocumento());
		preparedStatement.setString(3, object.getApellido());
		preparedStatement.setString(4, object.getNombres());
		preparedStatement.setString(5, object.getDomicilio());
		preparedStatement.setString(6, object.getTelefono());
		preparedStatement.setString(7, object.getCorreoElectronico());
		preparedStatement.setDate(8, java.sql.Date.valueOf(object.getFechaNacimiento()));
		preparedStatement.setDate(9, java.sql.Date.valueOf(object.getFechaIngreso()));
		preparedStatement.setLong(10, object.getId());
	}
	

	@Override
	protected Profesores populate(ResultSet rs) throws SQLException {
		Date d = rs.getDate(9);
		Date d2 = rs.getDate(10);
		LocalDate date =null;
		LocalDate date1 = null;
		
		if (d != null) {
			date = d.toLocalDate();	
		}
		
		if (d2 != null) {
			date1 = d2.toLocalDate();			
		}
		
		Long id = rs.getLong(1);
		String cuil = rs.getString(2);
		Long numeroDocumento = rs.getLong(3);
		String apellido = rs.getString(4);
		String nombre = rs.getString(5);
		String domicilio = rs.getString(6);
		String telefono = rs.getString(7);
		String email = rs.getString(8);
		LocalDate fechaNacimiento = date;
		LocalDate fechaIngreso = date1;
		Profesores p = new Profesores(numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, cuil,  fechaIngreso);
		p.setId(id);
		return p;
	}
	
	public static void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS PROFESOR ("
				+ "id long(11) NOT NULL AUTO_INCREMENT, "
				+ "cuil text NOT NULL, "
				+ "numeroDocumento long NOT NULL, "
				+ "apellido text NOT NULL, "
				+ "nombre text NOT NULL, "
				+ "domicilio text , "
				+ "telefono text , "
				+ "email text , "
				+ "fechaNacimiento date , "
				+ "fechaIngreso date ,"
				+ " PRIMARY KEY (id))");
		st.close();
	}
	
	//DEVUELVE UNA LISTA CON TODOS LOS NOMBRES, APELLIDOS Y DNI DE TODOS LOS PROFESORES
	public List<Profesores> DniNomApe() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT nombre, apellido, numeroDocumento from PROFESOR";
		
		List<Profesores> profes = new ArrayList<>();
		ResultSet rs = st.executeQuery(query);
		
		while (rs.next()) {
			Profesores aux = new Profesores(rs.getLong(3), rs.getString(2), rs.getString(1));
			
			profes.add(aux);
			
		} 
		
		return profes;
		
	}
	
	//EXTRAIGO UN PROFESOR SEGUN SU DNI
	public Profesores DatosProfeGuardar(Long dni) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, cuil , fechaIngreso , id from PROFESOR where numeroDocumento =" + dni;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			Date d = rs.getDate(4);
			Date d2 = rs.getDate(9);
			LocalDate date =null;
			LocalDate date1 = null;
			
			if (d != null) {
				date = d.toLocalDate();	
			}
			
			if (d2 != null) {
				date1 = d2.toLocalDate();			
			}
			
			Profesores profe = new Profesores(rs.getLong(1),rs.getString(2),rs.getString(3),date, rs.getString(5),rs.getString(6), rs.getString(7), rs.getString(8), date1);
			
			
			profe.setId(rs.getLong(10));
			
			return profe;

		}
		
		return null;
		
	}
	
	//VALIDO QUE EN LA BASE DE DATOS NO EXISTA YA UN PROFESOR CON ESE MISMO DNI INGRESADO
	public boolean ValidarProfesor (Long numDoc) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query = "SELECT numeroDocumento FROM PROFESOR WHERE numeroDocumento=" + numDoc;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			Long aux = rs.getLong(1);
			if(aux == numDoc) {
				return false;
			}else {
				return true;
			}	
		}
		
		return true;
		
	}
	
	//EXTRAIGO EL ID DE UN PROFESOR SEGUN SU DNI
	public long ExtraerId(Long numDoc) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query = "SELECT id FROM PROFESOR WHERE numeroDocumento=" + numDoc;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			Long aux = rs.getLong(1);
			return aux;
		}
		return numDoc;
	}
	
	//EXTRAIGO UN PROFESOR SEGUN SU ID
	public Profesores ExtraerUnProfesor(long id) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, cuil , fechaIngreso from PROFESOR where id =" + id;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			
			Date d = rs.getDate(4);
			Date d2 = rs.getDate(9);
			LocalDate date =null;
			LocalDate date1 = null;
			
			if (d != null) {
				date = d.toLocalDate();	
			}
			
			if (d2 != null) {
				date1 = d2.toLocalDate();			
			}
			Profesores profe = new Profesores(rs.getLong(1),rs.getString(2),rs.getString(3),date, rs.getString(5),rs.getString(6), rs.getString(7), rs.getString(8), date1);
			profe.setId(id);
			
			return profe;
		}
		return null;
	}
	
	//SE ELIMINA UN PROFESOR SEGUN SU DNI, TAMBIEN SE ELIMINARAN TODAS LAS ASIGNATURAS VINCULADAS CON ESTE PROFESOR.
	public void EliminarProfesor(Long dni) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "DELETE from PROFESOR where numeroDocumento =" + dni;
		st.execute(query);
		
		
	}
	
	
}
