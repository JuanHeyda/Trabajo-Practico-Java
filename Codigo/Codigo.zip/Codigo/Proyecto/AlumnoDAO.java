/**
 * 
 */
package Proyecto;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import ar.com.gugler.sgc.modelo.Alumno;

/**
 * @author Renzo Carletti & Heyda Juan Pablo
 *
 */
public class AlumnoDAO extends GenericDAO<Alumno> {
	
	
	@Override
	public String getTable() {
		return "ALUMNO";
	}

	@Override
	protected String getInsertSql() {
		return "insert into ALUMNO (legajo,numeroDocumento, apellido, "
				+ "nombre, domicilio, telefono, email, fechaNacimiento) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Alumno object) throws SQLException {
		
		preparedStatement.setString(1, object.getLegajo());
		preparedStatement.setLong(2, object.getNumeroDocumento());
		preparedStatement.setString(3, object.getApellido());
		preparedStatement.setString(4, object.getNombres());
		preparedStatement.setString(5, object.getDomicilio());
		preparedStatement.setString(6, object.getTelefono());
		preparedStatement.setString(7, object.getCorreoElectronico());
		preparedStatement.setDate(8, java.sql.Date.valueOf(object.getFechaNacimiento()));
	}

	@Override
	protected String getUpdateSql() {
		return "update ALUMNO set legajo = ?, numeroDocumento = ?, apellido = ?, "
				+ "nombre = ?, domicilio = ?, telefono = ?, "
				+ "email = ?, fechaNacimiento = ?" + "where id = ? ";
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Alumno object) throws SQLException {
		preparedStatement.setString(1, object.getLegajo());
		preparedStatement.setLong(2, object.getNumeroDocumento());
		preparedStatement.setString(3, object.getApellido());
		preparedStatement.setString(4, object.getNombres());
		preparedStatement.setString(5, object.getDomicilio());
		preparedStatement.setString(6, object.getTelefono());
		preparedStatement.setString(7, object.getCorreoElectronico());
		preparedStatement.setDate(8, java.sql.Date.valueOf(object.getFechaNacimiento()));
		preparedStatement.setLong(9, object.getId());
	}
	

	@Override
	protected Alumno populate(ResultSet rs) throws SQLException {
		Date d = rs.getDate(9);
		LocalDate date =null;
		
		if (d != null) {
			date = d.toLocalDate();	
		}
		
		Long id = rs.getLong(1);
		String legajo = rs.getString(2);
		Long numeroDocumento = rs.getLong(3);
		String apellido = rs.getString(4);
		String nombre = rs.getString(5);
		String domicilio = rs.getString(6);
		String telefono = rs.getString(7);
		String email = rs.getString(8);
		LocalDate fechaNacimiento = date;
		Alumno p = new Alumno(numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, legajo);
		p.setId(id);
		return p;
	}
	
	public static void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS ALUMNO ("
				+ "id long(11) NOT NULL AUTO_INCREMENT, "
				+ "legajo text NOT NULL, "
				+ "numeroDocumento long NOT NULL, "
				+ "apellido text NOT NULL, "
				+ "nombre text NOT NULL, "
				+ "domicilio text , "
				+ "telefono text , "
				+ "email text , "
				+ "fechaNacimiento date , "
				+ " PRIMARY KEY (id))");
		st.close();
	}
	
	//VALIDO UN USUARIO SEGUN TODOS SUS DATOS, NO SE VAN A PODER AGREGAR DOS PERSONAS IDENTICAS.
	public boolean ValidarUsuario(Long numeroDocumento, String apellido, String nombres, LocalDate fechaNacimiento, String domicilio, String telefono
			, String correoElectronico, String Legajo) throws SQLException {

		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT nombre from ALUMNO WHERE legajo =  '"+ Legajo +"' AND numeroDocumento = "+ numeroDocumento +" AND apellido = '"+ apellido +"'"
				+" AND nombre = '"+ nombres +"'"+" AND domicilio = '" + domicilio +"'"+" AND telefono = '"+ telefono +"'";
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			String name= rs.getString(1);
		
			if(name!= null) {
				return true;
			}
		} 
		return false;
		
	}
	
	//DEVUELVO UNA LISTA DE LOS ALUMNOS CON SUS NOMBRES, APELLIDOS Y NUMERO DE DOCUMENTO, UTILIZADOS MAS QUE NADA PARA MOSTRAR O EN LOS CHECKBOX
	public List<Alumno> NombreAlum() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT nombre, apellido, numeroDocumento from ALUMNO";
		
		List<Alumno> aux = new ArrayList<>();
		
		ResultSet rs = st.executeQuery(query);
		
		while (rs.next()) {
			
			Alumno alu = new Alumno(rs.getLong(3), rs.getString(2), rs.getString(1));
			
			aux.add(alu);
			
		} 
		return aux;
		
	}
	
	
	//LE LLEGA UNA LISTA DE DNI Y VA A DEVOLVER TODOS LOS ALUMNOS QUE HAY EN DICHA LISTA 
	public List<Alumno> AlumnosGuardar(List<Long> dni) throws SQLException{

		Statement st = Connection.getInstance().getConnection().createStatement();
		
		List<Alumno> aux = new ArrayList<>();
		
		for(int i = 0; i < dni.size(); i++) {
			
			String query= "SELECT numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, legajo , id from ALUMNO where numeroDocumento =" + dni.get(i);
			
			ResultSet rs = st.executeQuery(query);
			
			if (rs.next() == true) {
				
				Date d = rs.getDate(4);
				LocalDate date =null;
				
				if (d != null) {
					date = d.toLocalDate();	
				}
				Alumno alu = new Alumno(rs.getLong(1), rs.getString(2), rs.getString(3), date, rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
			
				alu.setId(rs.getLong(9));
				
				aux.add(alu);
			}
			
		}
		return aux;
	}
	
	
	//LE LLEGA UN DNI Y DEVUELVE TODOS LOS DATOS DE UN ALUMNO 
	public Alumno DatosAlumGuardar(Long dni) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, Legajo, id from ALUMNO where numeroDocumento =" + dni;
		
		ResultSet rs = st.executeQuery(query);

		Alumno alum = new Alumno();
		
		if (rs.next() == true) {
			Date d = rs.getDate(4);
			LocalDate date =null;
			
			if (d != null) {
				date = d.toLocalDate();	
			}
			alum.setNumeroDocumento(rs.getLong(1));
			alum.setApellido(rs.getString(2));
			alum.setNombres(rs.getString(3));
			alum.setFechaNacimiento(date);
			alum.setDomicilio(rs.getString(5));
			alum.setTelefono(rs.getString(6));
			alum.setCorreoElectronico(rs.getString(7));
			alum.setLegajo(rs.getString(8));
			alum.setId(rs.getLong(9));

		}
		return alum;
		
	}
	
	//LE LLEGA UN NUMERO DE DOCUMENTO Y VA A DEVOLVER SOLO EL ID, ESTO ES MAS QUE NADA PARA LA MODIFICACION DE EL ALUMNO.
	public long ExtraerId(Long numDoc) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query = "SELECT id FROM ALUMNO WHERE numeroDocumento=" + numDoc;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			Long aux = rs.getLong(1);
			return aux;
		}
		return numDoc;
	}
	
	//SEGUN UN ID VA A DEVOLVER TODOS LOS DATOS DE UN SOLO ALUMNO.
	public Alumno ExtraerUnAlumno(Long id) throws SQLException {
	    Statement st = Connection.getInstance().getConnection().createStatement();
	
	    String query= "SELECT numeroDocumento, apellido, nombre, fechaNacimiento, domicilio, telefono, email, legajo from ALUMNO where id =" + id;
	    ResultSet rs = st.executeQuery(query);
	
	    if (rs.next() == true) {
	        Date d = rs.getDate(4);
	        LocalDate date =null;
	
	        if (d != null) {
	            date = d.toLocalDate();
	        }
	        Alumno alu = new Alumno(rs.getLong(1), rs.getString(2), rs.getString(3), date, rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
	        alu.setId(id);
	
	        return alu;
	    }
	    return null;
	}
	
	//ELIMINA UN ALUMNO, AL ESTAR EL ON DELETE CASCADE SE VA A ELIMINAR TODO LO QUE ESTE VINCULADO CON ESE ALUMNO.
	public void EliminarAlumno(Long dni) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "DELETE from ALUMNO where numeroDocumento =" + dni;
		st.execute(query);
	}
	
}
