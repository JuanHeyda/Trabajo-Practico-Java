package Proyecto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ar.com.gugler.sgc.modelo.Asignatura;

/**
 * @author Renzo Carletti & Heyda Juan Pablo
 */

public class AsignaturaDAO extends GenericDAO<Asignatura> {
	
	@Override
	public String getTable() {
		return "ASIGNATURA";
	}

	@Override
	protected String getInsertSql() {
		return "insert into ASIGNATURA (ASIG_CODIGO, ASIG_NOMBRE, ASIG_PROFESOR, ASIG_ALUMNO, ASIG_MATERIA, ASIG_CURSO) "
				+ "values (?,?,?,?,?,?) ";
	}

	@Override
	protected void setValuesInsert(PreparedStatement preparedStatement, Asignatura object) throws SQLException {
		preparedStatement.setInt(1, object.getCodigo());
		preparedStatement.setString(2, object.getNombre());
		preparedStatement.setLong(3, object.getProfesor().getId());
		preparedStatement.setLong(4, object.getListaAlumnos().get(object.getListaAlumnos().size()-1).getId());
		preparedStatement.setLong(5, object.getMateria().getId());
		preparedStatement.setLong(6, object.getCurso().getId());
	}

	@Override
	protected String getUpdateSql() {
		return "update ASIGNATURA set ASIG_CODIGO = ?, ASIG_NOMBRE = ?, ASIG_PROFESOR = ?, ASIG_ALUMNO = ?, ASIG_MATERIA = ?, ASIG_CURSO = ?  "
				+ "where ID = ? ";
	}

	@Override
	protected void setValuesUpdate(PreparedStatement preparedStatement, Asignatura object) throws SQLException {
		preparedStatement.setInt(1, object.getCodigo());
		preparedStatement.setString(2, object.getNombre());
		preparedStatement.setLong(3, object.getProfesor().getId());
		preparedStatement.setLong(4, object.getListaAlumnos().get(object.getListaAlumnos().size()-1).getId());
		preparedStatement.setLong(5, object.getMateria().getId());
		preparedStatement.setLong(6, object.getCurso().getId());
		preparedStatement.setLong(7, object.getId());
	}

	@Override
	protected Asignatura populate(ResultSet rs) throws SQLException {
		int codigo= rs.getInt(1);
		String nombre= rs.getString(2);
		Long idProfesor= rs.getLong(3);
		Long idAlumno= rs.getLong(4);
		Long idMateria= rs.getLong(5);
		Long idCurso = rs.getLong(6);
		Long id = rs.getLong(7);
		
		Asignatura A = new Asignatura(codigo,nombre,idAlumno,idProfesor, idMateria, idCurso);
		A.setId(id);
		return A;
	}

	public static void createTable() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS ASIGNATURA ("
				+ "id long(11) NOT NULL AUTO_INCREMENT, "
				+ "ASIG_CODIGO int(11) NOT NULL , "
				+ "ASIG_NOMBRE varchar(20) NOT NULL , "
				+ "ASIG_PROFESOR long(11) NOT NULL , "
				+ "ASIG_ALUMNO long(11) NOT NULL , "
				+ "ASIG_MATERIA long(11) NOT NULL ,"
				+ "ASIG_CURSO long(11) NOT NULL , "
				+ " FOREIGN KEY (ASIG_PROFESOR) REFERENCES PROFESOR (id) ON DELETE CASCADE, "
				+ " FOREIGN KEY (ASIG_ALUMNO) REFERENCES ALUMNO (id) ON DELETE CASCADE, "
				+ " FOREIGN KEY (ASIG_MATERIA) REFERENCES MATERIAS (id) ON DELETE CASCADE, "
				+ " FOREIGN KEY (ASIG_CURSO) REFERENCES CURSO (id) ON DELETE CASCADE, "
				+ " PRIMARY KEY (id))");
		
		st.close();
	}
	
	public List<Long> ExtraerIdsElementos() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		String query = "SELECT id FROM ASIGNATURA";
		
		ResultSet rs = st.executeQuery(query);
		
		List<Long> cantidad = new ArrayList<Long>();
		
		while(rs.next()) {
			
			cantidad.add(rs.getLong(1));
			
		}
		
		return cantidad;
	}
	
	public List<Asignatura> ExtraerTodasLasAsignaturas() throws SQLException{
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		List<Long> ids = ExtraerIdsElementos();
		List<Asignatura> asignaturas = new ArrayList<Asignatura>();
		
		for(int i = 0 ; i < ids.size(); i++) {
			String query = "Select ASIG_CODIGO, ASIG_NOMBRE, ASIG_PROFESOR, ASIG_ALUMNO, ASIG_MATERIA, ASIG_CURSO FROM ASIGNATURA WHERE id =" + ids.get(i);
			ResultSet rs = st.executeQuery(query);
			
			if(rs.next() == true) {
				if((asignaturas.isEmpty()) || (rs.getInt(1) != asignaturas.get(asignaturas.size()-1).getCodigo())) {
					ProfesorDAO profesao= new ProfesorDAO();
					Asignatura asig = new Asignatura();
					AlumnoDAO alumao= new AlumnoDAO();
					MateriaDAO mateDao = new MateriaDAO();
					CursoDAO curDao = new CursoDAO();
					
					asig.setCodigo(rs.getInt(1));
					asig.setNombre(rs.getString(2));
					asig.setProfesor(profesao.ExtraerUnProfesor(rs.getLong(3)));
					asig.setAlumno(alumao.ExtraerUnAlumno(rs.getLong(4)));
					asig.setMateria(mateDao.ExtraerUnaMateria(rs.getLong(5)));
					asig.setCurso(curDao.ExtraerUnCurso(rs.getLong(6)));
					
					asignaturas.add(asig);
					
				}else if(rs.getInt(1) == asignaturas.get(asignaturas.size()-1).getCodigo()) {
					AlumnoDAO alumao= new AlumnoDAO();
					
					asignaturas.get(asignaturas.size()-1).setAlumno(alumao.ExtraerUnAlumno(rs.getLong(4)));
				}
			}
		}
		return asignaturas;
			
	}
	
	//VALIDA UNA ASIGNATURA SEGUN UN CODIGO, ASI NO EXISTEN DOS ASIGNATURAS IGUALES.
	public boolean ValidarAsignatura (int codAsignatura) throws SQLException {
		
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query = "SELECT ASIG_CODIGO FROM ASIGNATURA WHERE ASIG_CODIGO=" + codAsignatura;
		
		ResultSet rs = st.executeQuery(query);
		
		if (rs.next() == true) {
			int aux = rs.getInt(1);
			if(aux == codAsignatura) {
				return false;
			}else {
				return true;
			}	
		}
		
		return true;
		
	}
	
	//VA A DEVOLVER UN LISTADO DE LOS CODIGOS Y NOMBRES DE TODAS LAS ASIGNATURAS.
	public List<String> CodNombre() throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		String query= "SELECT ASIG_CODIGO, ASIG_NOMBRE from ASIGNATURA";
		
		List<String> codNom = new ArrayList<>();
		ResultSet rs = st.executeQuery(query);
		
		while (rs.next()) {
			codNom.add(rs.getInt(1) + " " + rs.getString(2));
		} 
		return codNom;
		
	}
	
	//DEVUELVE TODOS LOS DATOS DE UNA ASIGNATURA SEGUN UN CODIGO DE ASIGNATURA, ESTO ES PARA MOSTRAR O PARA MODIFICAR DICHA ASIGNATURA
	public Asignatura AsignaturaModificar(int codAsig) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		String query = "Select  ASIG_NOMBRE, ASIG_PROFESOR, ASIG_MATERIA, ASIG_CURSO, ASIG_ALUMNO FROM ASIGNATURA WHERE ASIG_CODIGO =" + codAsig;
		ResultSet rs = st.executeQuery(query);
		Asignatura asig = new Asignatura();
		asig.setNombre("");
		while (rs.next()) {
			AlumnoDAO alumDao = new AlumnoDAO();
			
			if(asig.getNombre().equals("")) {
				ProfesorDAO profeDao = new ProfesorDAO();
				MateriaDAO mateDao = new MateriaDAO();
				CursoDAO cursoDao = new CursoDAO();
				
				asig.setCodigo(codAsig);
				asig.setNombre(rs.getString(1));
				asig.setProfesor(profeDao.ExtraerUnProfesor(rs.getLong(2)));
				asig.setMateria(mateDao.ExtraerUnaMateria(rs.getLong(3)));
				asig.setCurso(cursoDao.ExtraerUnCurso(rs.getLong(4)));
				asig.AgregarElementoAlumno(alumDao.ExtraerUnAlumno(rs.getLong(5)));
			}else {
				asig.AgregarElementoAlumno(alumDao.ExtraerUnAlumno(rs.getLong(5)));
			}
			
		} 
		return asig;
	}
	
	//LE LLEGA EL CODIGO DE ASIGNATURA Y UN ID DE UN ALUMNO, ESTO ES PARA SACAR EL ID DE LA ASIGNATURA Y ASI PODER MODIFICARLA O SIMPLEMENTE BORRAR ESA ASIGNATURA SEGUN EL ID DE ESE ALUMNO.
	public Long ExtraerIdAsignatura(int codAsig , long idAlum) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		String query = "SELECT ID FROM ASIGNATURA WHERE ASIG_ALUMNO =" + idAlum + "AND ASIG_CODIGO =" + codAsig;
		ResultSet rs = st.executeQuery(query);
		
		if(rs.next() == true) {
			return rs.getLong(1);
		}
		return -1L;
	}
	
	//ELIMINO LA ASIGNATURA SEGUN EL ALUMNO ESPECIFICO.
	public void EliminarAsignaturaAlumno(long idAsig) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		String query =  "DELETE FROM ASIGNATURA WHERE ID =" + idAsig;
		st.execute(query);
	}
	
	//ELIMINA UNA ASINGATURA COMPLETA, SEGUN EL CODIGO DE ASIGNATURA, VA A BORRAR TODOS LOS ALUMNOS INCLUIDOS EN LA ASIGNATURA.
	public void EliminarAsignatura(int codAsig) throws SQLException {
		Statement st = Connection.getInstance().getConnection().createStatement();
		
		String query =  "DELETE FROM ASIGNATURA WHERE ASIG_CODIGO =" + codAsig;
		st.execute(query);
		
	}	
	
	
	
}
